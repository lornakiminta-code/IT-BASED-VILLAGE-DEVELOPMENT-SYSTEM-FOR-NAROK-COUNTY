<?php
require_once 'config.php';

// Get statistics
$resident_count = $conn->query("SELECT COUNT(*) as count FROM residents")->fetch_assoc()['count'];
$project_count = $conn->query("SELECT COUNT(*) as count FROM projects")->fetch_assoc()['count'];
$ongoing_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status='Ongoing'")->fetch_assoc()['count'];
$completed_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status='Completed'")->fetch_assoc()['count'];
$feedback_count = $conn->query("SELECT COUNT(*) as count FROM feedback WHERE status='Pending'")->fetch_assoc()['count'];
$total_budget = $conn->query("SELECT SUM(budget) as total FROM projects")->fetch_assoc()['total'];

// Get recent projects
$recent_projects = $conn->query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 5");

// Get recent communications
$recent_comms = $conn->query("SELECT * FROM communications ORDER BY sent_date DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Narok County</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%);
            padding: 15px;
        }
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            color: white !important;
        }
        .nav-link {
            color: rgba(255,255,255,0.9) !important;
        }
        .nav-link:hover {
            color: white !important;
        }
        .stat-card {
            background: white;
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s;
            margin-bottom: 20px;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.2;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .section-title {
            border-left: 4px solid #1a5f7a;
            padding-left: 15px;
            margin: 25px 0 20px 0;
        }
        footer {
            background: #2c3e50;
            color: white;
            padding: 30px 0;
            margin-top: 50px;
        }
        .btn-custom {
            background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%);
            border: none;
            color: white;
        }
        .btn-custom:hover {
            background: linear-gradient(135deg, #159895 0%, #1a5f7a 100%);
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <i class="fas fa-village"></i> <?php echo SITE_NAME; ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="residents.php">Residents</a></li>
                <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="communications.php">Announcements</a></li>
                <li class="nav-item"><a class="nav-link" href="feedback.php">Feedback</a></li>
                <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Page</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<div class="bg-primary text-white py-5" style="background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%) !important;">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h1 class="display-4 fw-bold">Welcome to Narok Digital Village</h1>
                <p class="lead">Empowering rural communities through technology and transparent development tracking.</p>
                <a href="projects.php" class="btn btn-light btn-lg mt-3">View Projects <i class="fas fa-arrow-right"></i></a>
                <a href="feedback.php" class="btn btn-outline-light btn-lg mt-3 ms-2">Give Feedback <i class="fas fa-comment"></i></a>
            </div>
            <div class="col-md-4 text-center">
                <i class="fas fa-village fa-5x"></i>
            </div>
        </div>
    </div>
</div>

<div class="container py-4">
    <?php display_message(); ?>
    
    <!-- Statistics Section -->
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="card stat-card position-relative">
                <div class="card-body">
                    <h5 class="card-title text-muted">Total Residents</h5>
                    <h2 class="display-4"><?php echo $resident_count; ?></h2>
                    <i class="fas fa-users stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card position-relative">
                <div class="card-body">
                    <h5 class="card-title text-muted">Development Projects</h5>
                    <h2 class="display-4"><?php echo $project_count; ?></h2>
                    <i class="fas fa-project-diagram stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card position-relative">
                <div class="card-body">
                    <h5 class="card-title text-muted">Ongoing Projects</h5>
                    <h2 class="display-4"><?php echo $ongoing_projects; ?></h2>
                    <i class="fas fa-spinner stat-icon"></i>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stat-card position-relative">
                <div class="card-body">
                    <h5 class="card-title text-muted">Total Budget</h5>
                    <h2 class="display-6">KES <?php echo number_format($total_budget / 1000000, 1); ?>M</h2>
                    <i class="fas fa-money-bill-wave stat-icon"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Projects Section -->
    <h3 class="section-title"><i class="fas fa-project-diagram me-2"></i>Recent Development Projects</h3>
    <div class="row">
        <?php while($project = $recent_projects->fetch_assoc()): ?>
        <div class="col-md-4 mb-3">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h5 class="card-title"><?php echo $project['project_name']; ?></h5>
                        <span class="badge bg-<?php echo $project['status'] == 'Completed' ? 'success' : ($project['status'] == 'Ongoing' ? 'primary' : 'warning'); ?>">
                            <?php echo $project['status']; ?>
                        </span>
                    </div>
                    <p class="text-muted small">Code: <?php echo $project['project_code']; ?> | Type: <?php echo $project['project_type']; ?></p>
                    <p class="card-text small"><?php echo substr($project['description'], 0, 100); ?>...</p>
                    <div class="mb-2">
                        <small>Progress: <?php echo $project['progress']; ?>%</small>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar" style="width: <?php echo $project['progress']; ?>%"></div>
                        </div>
                    </div>
                    <div class="row small">
                        <div class="col-6"><strong>Budget:</strong><br>KES <?php echo number_format($project['budget'], 0); ?></div>
                        <div class="col-6"><strong>Village:</strong><br><?php echo $project['village']; ?></div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    
    <!-- Announcements Section -->
    <h3 class="section-title"><i class="fas fa-bullhorn me-2"></i>Latest Announcements</h3>
    <div class="row">
        <div class="col-md-8">
            <?php while($comm = $recent_comms->fetch_assoc()): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6><i class="fas fa-bullhorn"></i> <?php echo $comm['title']; ?></h6>
                        <small class="text-muted"><?php echo date('M j, Y', strtotime($comm['sent_date'])); ?></small>
                    </div>
                    <p class="mb-0 small"><?php echo substr($comm['message'], 0, 150); ?>...</p>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        <div class="col-md-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h6><i class="fas fa-info-circle"></i> Quick Contacts</h6>
                    <hr>
                    <p><i class="fas fa-phone"></i> Chief's Office: <strong>0700 000 000</strong></p>
                    <p><i class="fas fa-ambulance"></i> Health Center: <strong>0700 111 111</strong></p>
                    <p><i class="fas fa-shield-alt"></i> Police Post: <strong>0700 222 222</strong></p>
                    <hr>
                    <p><strong>Next Baraza:</strong><br>1st & 15th of every month<br>10:00 AM at Village Center</p>
                    <a href="feedback.php" class="btn btn-custom btn-sm w-100">Give Feedback <i class="fas fa-paper-plane"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer>
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Narok County, Kenya</p>
        <p><small>Empowering rural development through Information Technology</small></p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>