-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2026 at 11:37 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `village_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `communications`
--

CREATE TABLE `communications` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` int(11) NOT NULL,
  `type` text NOT NULL,
  `target_audience` text NOT NULL,
  `village` varchar(100) NOT NULL,
  `posted_by` text NOT NULL,
  `sent_date` datetime NOT NULL,
  `sent_by` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `communications`
--

INSERT INTO `communications` (`id`, `title`, `message`, `type`, `target_audience`, `village`, `posted_by`, `sent_date`, `sent_by`, `is_active`) VALUES
(1, 'updates', 0, 'Emergency', 'Village Elders', 'juja', 'Village Administrator', '0000-00-00 00:00:00', 0, 0),
(2, 'mki', 0, 'Announcement', 'All', 'juja', 'Village Administrator', '0000-00-00 00:00:00', 0, 0),
(3, 'lk;j', 0, 'Announcement', 'All', '', 'Village Administrator', '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('pending','read','replied') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `contactss`
--

CREATE TABLE `contactss` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactss`
--

INSERT INTO `contactss` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, 'manuuh manuela', 'manuuhmanuela78@gmail.com', 'yn89gb', ',hlvkl');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `resident_name` varchar(11) NOT NULL,
  `resident_phone` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` int(11) NOT NULL,
  `type` text NOT NULL,
  `status` text NOT NULL,
  `response` int(11) NOT NULL,
  `response_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `resident_name`, `resident_phone`, `subject`, `message`, `type`, `status`, `response`, `response_date`, `created_at`) VALUES
(1, 'mike', 'un8hg', 'yn89gb', 8, 'Complaint', 'Resolved', 0, '2026-06-08', '2026-06-08 11:45:17');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_code` varchar(100) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `project_type` text NOT NULL,
  `description` text NOT NULL,
  `location` varchar(100) NOT NULL,
  `village` varchar(100) NOT NULL,
  `budget` decimal(10,2) NOT NULL,
  `start_date` date NOT NULL,
  `expected_end_date` date NOT NULL,
  `contractor` varchar(100) NOT NULL,
  `supervisor_name` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `progress` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_code`, `project_name`, `project_type`, `description`, `location`, `village`, `budget`, `start_date`, `expected_end_date`, `contractor`, `supervisor_name`, `status`, `progress`, `created_by`, `created_at`) VALUES
(1, '7899', 'expansion', 'Health', 'murraming and expansion', 'jiji', 'juja', '100000.00', '2026-06-11', '2026-07-09', 'mosee', 0, 'Completed', 100, 0, '2026-06-08 11:26:24'),
(2, '7899', 'expansion', 'Roads', '009', 'jiji', 'juja', '9000.00', '2026-06-18', '2026-06-24', 'mosee', 0, 'Ongoing', 70, 0, '2026-06-18 20:25:43');

-- --------------------------------------------------------

--
-- Table structure for table `project_updates`
--

CREATE TABLE `project_updates` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `update_date` date NOT NULL,
  `progress_percentage` int(11) NOT NULL,
  `description` int(11) NOT NULL,
  `amount_spent` decimal(10,2) NOT NULL,
  `challenges` text NOT NULL,
  `next_plan` text NOT NULL,
  `photo_path` varchar(100) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project_updates`
--

INSERT INTO `project_updates` (`id`, `project_id`, `update_date`, `progress_percentage`, `description`, `amount_spent`, `challenges`, `next_plan`, `photo_path`, `updated_by`, `created_at`) VALUES
(1, 1, '2026-06-08', 70, 0, '9000.00', '', '', '', 0, '2026-06-08 11:38:01'),
(2, 1, '2026-06-08', 100, 0, '800000.00', '', '', '', 0, '2026-06-08 11:49:35'),
(3, 2, '2026-06-19', 70, 0, '9000000.00', '', '', '', 0, '2026-06-18 21:10:49');

-- --------------------------------------------------------

--
-- Table structure for table `residents`
--

CREATE TABLE `residents` (
  `id` int(11) NOT NULL,
  `national_id` varchar(100) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `gender` text NOT NULL,
  `date_of_birth` date NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `household_head` varchar(100) NOT NULL,
  `family_members` int(11) NOT NULL,
  `village` varchar(100) NOT NULL,
  `sub_location` varchar(100) NOT NULL,
  `occupation` varchar(100) NOT NULL,
  `education_level` varchar(100) NOT NULL,
  `registration_date` date NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `residents`
--

INSERT INTO `residents` (`id`, `national_id`, `full_name`, `gender`, `date_of_birth`, `phone`, `email`, `household_head`, `family_members`, `village`, `sub_location`, `occupation`, `education_level`, `registration_date`, `created_by`) VALUES
(1, '37890', 'manuuh manuela', 'Male', '0000-00-00', '0712345678', 'manuuhmanuela78@gmail.com', '34', 1, 'juja', 'jujaaa', 'teacher', '', '2026-06-08', 0),
(2, '7890', 'mike', 'Male', '2009-06-10', '254706173408', 'manuuhmanuela78@gmail.com', '4', 1, 'kimbo', '', 'prof', '', '2026-06-08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `userr`
--

CREATE TABLE `userr` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass_word` varchar(100) NOT NULL,
  `confirm_pass_word` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userr`
--

INSERT INTO `userr` (`id`, `name`, `user_name`, `email`, `pass_word`, `confirm_pass_word`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 'admin123', ''),
(2, 'adminn', 'adminn', 'adminn@gmail.com', '123456', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `role` text NOT NULL,
  `status` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `phone`, `role`, `status`, `created_at`) VALUES
(1, 'admin', 'admin123', 'System Administrator', '0789898989', 'admin', '', '2026-06-08 11:11:44');

-- --------------------------------------------------------

--
-- Table structure for table `userss`
--

CREATE TABLE `userss` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `village` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userss`
--

INSERT INTO `userss` (`id`, `full_name`, `email`, `phone`, `village`, `password`, `role`, `created_at`) VALUES
(1, 'System Administrator', 'admin@village.com', '0712345678', 'Central Village', '$2y$10$A/vlhMLmbUDYS0WrbhGfmOgAJCV0BhKd1yh8sy0TFdQTBBTUmlJxC', 0, '2026-06-18 20:43:16'),
(2, 'manuuh manuelaj', 'man@gmail.com', '', 'kimbo', '$2y$10$R0IkCRA81aXdC9QO2CZE5OhHJScqf6dNyeJzEtMsubgO/q5ea3Db.', 0, '2026-06-18 20:45:03'),
(3, 'lim lim', 'lim@gmail.com', '254724753730', 'juja', '$2y$10$MXwCkzyAXyPCc7kspUvks.yZZI3IM7A6pfxtPQ2YN.wM8H5YJu2Me', 0, '2026-06-18 20:45:45');

-- --------------------------------------------------------

--
-- Table structure for table `village_resources`
--

CREATE TABLE `village_resources` (
  `id` int(11) NOT NULL,
  `resource_name` varchar(100) NOT NULL,
  `resource_type` text NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `status` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `communications`
--
ALTER TABLE `communications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactss`
--
ALTER TABLE `contactss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_updates`
--
ALTER TABLE `project_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `residents`
--
ALTER TABLE `residents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userr`
--
ALTER TABLE `userr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userss`
--
ALTER TABLE `userss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `village_resources`
--
ALTER TABLE `village_resources`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `communications`
--
ALTER TABLE `communications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contactss`
--
ALTER TABLE `contactss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `project_updates`
--
ALTER TABLE `project_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `residents`
--
ALTER TABLE `residents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `userr`
--
ALTER TABLE `userr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userss`
--
ALTER TABLE `userss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `village_resources`
--
ALTER TABLE `village_resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
