<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parking & Movers FAQ Assistant</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
        }

        /* Main content styling */
        .main-content {
            padding: 40px 20px;
            color: white;
            text-align: center;
        }

        .main-content h1 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .main-content p {
            font-size: 1.2rem;
            opacity: 0.9;
        }

        .services {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin-top: 50px;
            flex-wrap: wrap;
        }

        .service-card {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            padding: 30px;
            border-radius: 15px;
            width: 250px;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .service-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        /* Chatbot Styles */
        .chatbot-container {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        .chatbot-button {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: linear-gradient(135deg, #00b09b, #96c93d);
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            color: white;
            transition: all 0.3s ease;
            position: relative;
        }

        .chatbot-button:hover {
            transform: scale(1.1) rotate(5deg);
            box-shadow: 0 6px 25px rgba(0,0,0,0.4);
        }

        .chatbot-button .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ff4757;
            color: white;
            border-radius: 50%;
            width: 25px;
            height: 25px;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px solid white;
        }

        .chatbot-popup {
            position: absolute;
            bottom: 90px;
            right: 0;
            width: 380px;
            height: 600px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            display: none;
            flex-direction: column;
            overflow: hidden;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .chatbot-popup.active {
            display: flex;
        }

        .chatbot-header {
            background: linear-gradient(135deg, #00b09b, #96c93d);
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .bot-avatar {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .header-text h3 {
            font-size: 16px;
            font-weight: 600;
        }

        .header-text p {
            font-size: 12px;
            opacity: 0.9;
        }

        .close-btn {
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease;
        }

        .close-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .chatbot-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .message {
            display: flex;
            max-width: 85%;
        }

        .message.bot {
            align-self: flex-start;
        }

        .message.user {
            align-self: flex-end;
        }

        .message-content {
            padding: 12px 16px;
            border-radius: 18px;
            font-size: 14px;
            line-height: 1.5;
            word-wrap: break-word;
            position: relative;
        }

        .bot .message-content {
            background: white;
            border-bottom-left-radius: 5px;
            color: #2c3e50;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .user .message-content {
            background: linear-gradient(135deg, #00b09b, #96c93d);
            color: white;
            border-bottom-right-radius: 5px;
        }

        .message-time {
            font-size: 10px;
            color: #95a5a6;
            margin-top: 5px;
            margin-left: 12px;
        }

        .bot .message-time {
            margin-left: 12px;
        }

        .user .message-time {
            text-align: right;
            margin-right: 12px;
        }

        /* Quick Replies */
        .quick-replies-container {
            padding: 15px;
            background: white;
            border-top: 1px solid #ecf0f1;
        }

        .quick-replies-title {
            font-size: 12px;
            color: #7f8c8d;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .quick-replies {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .quick-reply-btn {
            padding: 8px 16px;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 20px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #2c3e50;
            white-space: nowrap;
        }

        .quick-reply-btn:hover {
            background: linear-gradient(135deg, #00b09b, #96c93d);
            color: white;
            border-color: transparent;
            transform: translateY(-2px);
        }

        /* Input Area */
        .chatbot-input-container {
            padding: 15px;
            background: white;
            border-top: 1px solid #ecf0f1;
        }

        .input-wrapper {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .chatbot-input {
            flex: 1;
            padding: 12px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 25px;
            outline: none;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .chatbot-input:focus {
            border-color: #00b09b;
            box-shadow: 0 0 0 3px rgba(0,176,155,0.1);
        }

        .send-btn {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #00b09b, #96c93d);
            border: none;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: all 0.3s ease;
        }

        .send-btn:hover {
            transform: scale(1.1) rotate(90deg);
        }

        .send-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Typing Indicator */
        .typing-indicator {
            display: flex;
            gap: 4px;
            padding: 15px 20px;
            background: white;
            border-radius: 25px;
            border-bottom-left-radius: 5px;
            width: fit-content;
        }

        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: #00b09b;
            border-radius: 50%;
            animation: typing 1.4s infinite ease-in-out;
        }

        .typing-indicator span:nth-child(2) {
            animation-delay: 0.2s;
        }

        .typing-indicator span:nth-child(3) {
            animation-delay: 0.4s;
        }

        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }

        /* Scrollbar Styling */
        .chatbot-messages::-webkit-scrollbar {
            width: 6px;
        }

        .chatbot-messages::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        .chatbot-messages::-webkit-scrollbar-thumb {
            background: #cbd5e0;
            border-radius: 3px;
        }

        .chatbot-messages::-webkit-scrollbar-thumb:hover {
            background: #a0aec0;
        }

        /* Responsive Design */
        @media (max-width: 480px) {
            .chatbot-popup {
                width: 340px;
                height: 550px;
                right: 0;
                bottom: 80px;
            }
            
            .main-content h1 {
                font-size: 2rem;
            }
        }

        /* FAQ Categories */
        .faq-category {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 10px;
            margin-top: 10px;
        }

        .category-title {
            font-size: 12px;
            color: #7f8c8d;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <h1>Parking & Moving Solutions</h1>
        <p>Your trusted partner for parking and relocation services</p>
        
        <div class="services">
            <div class="service-card">
                <h3>🚗 Parking</h3>
                <p>24/7 secure parking with CCTV surveillance</p>
            </div>
            <div class="service-card">
                <h3>📦 Moving</h3>
                <p>Professional moving and packing services</p>
            </div>
            <div class="service-card">
                <h3>🏠 Storage</h3>
                <p>Climate-controlled storage units</p>
            </div>
        </div>
    </div>

    <!-- Chatbot Container -->
    <div class="chatbot-container">
        <button class="chatbot-button" id="chatbotToggle">
            💬
            <span class="notification-badge" id="notificationBadge" style="display: none;">1</span>
        </button>
        
        <div class="chatbot-popup" id="chatbotPopup">
            <div class="chatbot-header">
                <div class="header-content">
                    <div class="bot-avatar">🤖</div>
                    <div class="header-text">
                        <h3>Parking & Movers Assistant</h3>
                        <p>Online • Usually replies instantly</p>
                    </div>
                </div>
                <button class="close-btn" id="closeChatbot">×</button>
            </div>
            
            <div class="chatbot-messages" id="chatMessages">
                <div class="message bot">
                    <div class="message-content">
                        👋 Hello! I'm your parking and moving assistant. 
                        <br><br>
                        I can help you with:
                        • Parking rates & availability
                        • Moving services & costs
                        • Packing & storage
                        • Reservations
                        • Contact information
                        <br><br>
                        What would you like to know?
                    </div>
                    <div class="message-time">Just now</div>
                </div>
            </div>
            
            <div class="quick-replies-container">
                <div class="quick-replies-title">Frequently Asked Questions</div>
                <div class="quick-replies" id="quickReplies">
                    <button class="quick-reply-btn" data-question="What are your parking rates?">💰 Parking Rates</button>
                    <button class="quick-reply-btn" data-question="Are you open 24/7?">🕒 Hours</button>
                    <button class="quick-reply-btn" data-question="How much do movers cost?">📦 Moving Cost</button>
                    <button class="quick-reply-btn" data-question="Do you offer packing services?">📦 Packing</button>
                    <button class="quick-reply-btn" data-question="How do I contact you?">📞 Contact</button>
                    <button class="quick-reply-btn" data-question="Is parking secure?">🔒 Security</button>
                </div>
            </div>
            
            <div class="chatbot-input-container">
                <div class="input-wrapper">
                    <input type="text" class="chatbot-input" id="userInput" 
                           placeholder="Type your question..." />
                    <button class="send-btn" id="sendMessage">
                        ➤
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // DOM Elements
            const chatbotToggle = document.getElementById('chatbotToggle');
            const chatbotPopup = document.getElementById('chatbotPopup');
            const closeChatbot = document.getElementById('closeChatbot');
            const sendButton = document.getElementById('sendMessage');
            const userInput = document.getElementById('userInput');
            const chatMessages = document.getElementById('chatMessages');
            const quickReplyBtns = document.querySelectorAll('.quick-reply-btn');
            const notificationBadge = document.getElementById('notificationBadge');

            // State
            let sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            let isTyping = false;
            let unreadCount = 1;

            // Toggle chatbot
            chatbotToggle.addEventListener('click', function() {
                chatbotPopup.classList.toggle('active');
                if (chatbotPopup.classList.contains('active')) {
                    userInput.focus();
                    notificationBadge.style.display = 'none';
                    unreadCount = 0;
                }
            });

            closeChatbot.addEventListener('click', function() {
                chatbotPopup.classList.remove('active');
            });

            // Send message function
            async function sendMessage(message) {
                if (!message.trim() || isTyping) return;

                // Add user message
                addMessage(message, 'user');
                
                // Clear input
                userInput.value = '';
                
                // Show typing indicator
                showTypingIndicator();
                isTyping = true;
                sendButton.disabled = true;

                try {
                    // Send to backend
                    const response = await fetch('chatbot_api.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            message: message,
                            session_id: sessionId
                        })
                    });

                    const data = await response.json();
                    
                    // Remove typing indicator
                    removeTypingIndicator();
                    
                    // Add bot response
                    addMessage(data.response, 'bot');
                    
                    // Update notification if chat is closed
                    if (!chatbotPopup.classList.contains('active')) {
                        unreadCount++;
                        notificationBadge.style.display = 'flex';
                        notificationBadge.textContent = unreadCount;
                    }
                } catch (error) {
                    console.error('Error:', error);
                    removeTypingIndicator();
                    addMessage('Sorry, I\'m having trouble connecting. Please try again or call us at (555) 123-4567', 'bot');
                } finally {
                    isTyping = false;
                    sendButton.disabled = false;
                }
            }

            function addMessage(text, sender) {
                const messageDiv = document.createElement('div');
                messageDiv.className = `message ${sender}`;
                
                const contentDiv = document.createElement('div');
                contentDiv.className = 'message-content';
                
                // Format message with line breaks
                contentDiv.style.whiteSpace = 'pre-line';
                contentDiv.textContent = text;
                
                const timeDiv = document.createElement('div');
                timeDiv.className = 'message-time';
                timeDiv.textContent = new Date().toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                });
                
                messageDiv.appendChild(contentDiv);
                messageDiv.appendChild(timeDiv);
                
                chatMessages.appendChild(messageDiv);
                scrollToBottom();
            }

            function showTypingIndicator() {
                const typingDiv = document.createElement('div');
                typingDiv.className = 'message bot';
                typingDiv.id = 'typingIndicator';
                
                const indicatorDiv = document.createElement('div');
                indicatorDiv.className = 'typing-indicator';
                
                for (let i = 0; i < 3; i++) {
                    const span = document.createElement('span');
                    indicatorDiv.appendChild(span);
                }
                
                typingDiv.appendChild(indicatorDiv);
                chatMessages.appendChild(typingDiv);
                scrollToBottom();
            }

            function removeTypingIndicator() {
                const typingIndicator = document.getElementById('typingIndicator');
                if (typingIndicator) {
                    typingIndicator.remove();
                }
            }

            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }

            // Event listeners
            sendButton.addEventListener('click', function() {
                sendMessage(userInput.value);
            });

            userInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage(userInput.value);
                }
            });

            // Quick reply buttons
            quickReplyBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const question = this.dataset.question;
                    sendMessage(question);
                });
            });

            // Add welcome suggestions after 2 seconds
            setTimeout(() => {
                if (chatMessages.children.length === 1) {
                    addMessage("💡 Try asking about parking rates, moving costs, or our hours!", 'bot');
                }
            }, 2000);

            // Handle input focus
            userInput.addEventListener('focus', function() {
                this.placeholder = '';
            });

            userInput.addEventListener('blur', function() {
                this.placeholder = 'Type your question...';
            });

            // Add emoji support for quick replies (optional)
            const emojiMap = {
                'parking rates': '💰',
                'hours': '🕒',
                'movers cost': '📦',
                'packing': '📦',
                'contact': '📞',
                'security': '🔒'
            };
        });
    </script>
</body>
</html>