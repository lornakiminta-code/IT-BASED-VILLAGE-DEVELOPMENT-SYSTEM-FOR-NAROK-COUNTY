<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Start session for conversation tracking
session_start();

// FAQ Data Array - Easy to modify and expand
$faq_responses = [
    // Parking FAQs
    'parking_rates' => [
        'keywords' => ['parking', 'rates', 'cost', 'price', 'fee', 'charge', 'how much'],
        'response' => "Our parking rates are:\n• Hourly: \$3 per hour\n• Daily: \$15 per day\n• Weekly: \$80 per week\n• Monthly: \$250 per month\n• Overnight: \$10 (6 PM - 6 AM)\n\n🎉 Special discount: 10% off for weekly/monthly bookings!"
    ],
    
    'parking_hours' => [
        'keywords' => ['hours', 'open', 'close', 'timing', '24/7', 'operation'],
        'response' => "🕒 Our parking facility is open 24/7, 365 days a year!\n\nCustomer Service Hours:\n• Monday-Friday: 8 AM - 8 PM\n• Saturday: 9 AM - 6 PM\n• Sunday: 10 AM - 4 PM"
    ],
    
    'parking_reservation' => [
        'keywords' => ['reserve', 'booking', 'book', 'spot', 'reservation', 'advance'],
        'response' => "✅ Yes, you can reserve parking spots in advance!\n\nWays to book:\n• 📱 Mobile App (iOS & Android)\n• 💻 Website: www.parkingmovers.com\n• 📞 Phone: (555) 123-4567\n\nEarly booking discount: 15% off when booking 3+ days in advance!"
    ],
    
    'parking_security' => [
        'keywords' => ['security', 'safe', 'safety', 'cctv', 'camera', 'guard', 'protection'],
        'response' => "🛡️ Your vehicle's safety is our priority:\n• 24/7 CCTV surveillance\n• Security guards on duty\n• Well-lit parking areas\n• Gated access with license plate recognition\n• Regular patrols\n• Emergency call buttons"
    ],
    
    'ev_charging' => [
        'keywords' => ['ev', 'electric', 'charging', 'tesla', 'charge', 'battery'],
        'response' => "⚡ EV Charging Stations Available!\n\n• Level 2 Chargers: \$2/hour\n• DC Fast Charging: \$10/session\n• Tesla Superchargers: Available\n• 10 charging spots total\n• Reserve via our app\n\n📍 Located on Level 2, near elevator B"
    ],
    
    'parking_capacity' => [
        'keywords' => ['capacity', 'full', 'space', 'available', 'spaces', 'vacancy'],
        'response' => "📊 Current Parking Status:\n• Total spaces: 500\n• Current availability: Check our app for real-time updates\n• Peak hours: 9 AM - 11 AM & 4 PM - 7 PM\n• Handicap spaces: 20 (Level 1)\n• Motorcycle parking: Available (Level 1)"
    ],

    // Movers FAQs
    'moving_cost' => [
        'keywords' => ['moving', 'movers', 'cost', 'price', 'estimate', 'quote', 'how much'],
        'response' => "📦 Moving Service Rates:\n\nLocal Moves (within 20 miles):\n• Studio/1BR: Starting at \$199\n• 2BR Apartment: Starting at \$299\n• 3BR House: Starting at \$499\n• 4+ BR: Starting at \$799\n\nLong Distance:\n• \$2.50 per mile + hourly rates\n\n📞 Call for FREE estimate: (555) 123-4567"
    ],
    
    'packing_services' => [
        'keywords' => ['packing', 'pack', 'boxes', 'supplies', 'wrap', 'materials'],
        'response' => "📦 Packing Services & Supplies:\n\nFull Packing Service:\n• Professional packers\n• High-quality materials\n• Starting at \$150\n\nSupplies Available:\n• Boxes: Small \$2, Medium \$3, Large \$4\n• Bubble wrap: \$10/roll\n• Packing tape: \$3/roll\n• Furniture covers: \$15 each\n\n💡 DIY packing guide available on our website!"
    ],
    
    'moving_insurance' => [
        'keywords' => ['insurance', 'cover', 'protection', 'damage', 'loss', 'claim'],
        'response' => "🛡️ Moving Insurance Options:\n\nBasic Coverage (Included):\n• 60¢ per pound per item\n• Basic liability protection\n\nFull Value Protection (Recommended):\n• 1% of declared value\n• Comprehensive coverage\n• Calls for replacement value\n\nAdditional Insurance:\n• Third-party insurance available\n• High-value item rider for jewelry/art\n\nAsk about our peace of mind guarantee!"
    ],
    
    'long_distance' => [
        'keywords' => ['long', 'distance', 'interstate', 'state', 'cross country', 'far'],
        'response' => "🚛 Long Distance Moving Services:\n\nWe cover:\n• Interstate moves\n• Cross-country relocation\n• International shipping\n\nWhat's included:\n• Professional loading/unloading\n• Secure transportation\n• Tracking updates\n• Delivery to your new home\n\n📞 Get a customized quote: (555) 123-4567"
    ],
    
    'storage' => [
        'keywords' => ['storage', 'warehouse', 'keep', 'hold', 'store'],
        'response' => "🏠 Storage Solutions:\n\nShort-term Storage:\n• \$50/month for small unit (5x5)\n• \$100/month for medium (10x10)\n• \$150/month for large (10x20)\n\nLong-term Storage:\n• 20% discount for 6+ months\n• Climate controlled\n• 24/7 security access\n• Free moving supplies with 3+ months\n\n📅 Reserve your storage unit today!"
    ],

    // General FAQs
    'contact_info' => [
        'keywords' => ['contact', 'phone', 'email', 'address', 'reach', 'call'],
        'response' => "📞 Get in touch with us:\n\nPhone: (555) 123-4567\n(24/7 emergency line)\n\nEmail: info@parkingmovers.com\nsupport@parkingmovers.com\n\n📍 Address:\n123 Main Street\nCity, State 12345\n\n🌐 Website: www.parkingmovers.com\n📱 App: Available on iOS and Android"
    ],
    
    'payment_methods' => [
        'keywords' => ['payment', 'pay', 'credit', 'card', 'cash', 'method'],
        'response' => "💳 Payment Methods Accepted:\n\n• Credit/Debit Cards (Visa, MC, Amex, Discover)\n• Cash\n• PayPal\n• Venmo\n• Zelle\n• Company checks (with approval)\n• Cryptocurrency (Bitcoin, Ethereum)\n\n📱 Pay via our app for 5% cashback!"
    ],
    
    'cancellation' => [
        'keywords' => ['cancel', 'cancellation', 'refund', 'change', 'modify'],
        'response' => "📋 Cancellation Policy:\n\nParking:\n• Free cancellation up to 2 hours before\n• 50% refund within 24 hours\n• No refund for no-shows\n\nMoving Services:\n• Full refund 48+ hours before\n• 50% refund 24-48 hours before\n• No refund within 24 hours\n\nTo cancel: Call (555) 123-4567 or use our app"
    ],
    
    'corporate_services' => [
        'keywords' => ['corporate', 'business', 'company', 'fleet', 'commercial'],
        'response' => "🏢 Corporate Services:\n\nParking:\n• Reserved corporate spots\n• Fleet parking discounts\n• Monthly invoicing\n\nMoving:\n• Office relocation\n• Employee relocation packages\n• Corporate accounts\n\nContact our corporate team: corporate@parkingmovers.com"
    ],
    
    'emergency' => [
        'keywords' => ['emergency', 'urgent', 'help', 'stuck', 'accident'],
        'response' => "🚨 Emergency Assistance:\n\n24/7 Emergency Line: (555) 999-8888\n\nParking Issues:\n• Gate malfunction: Press intercom\n• Vehicle stuck: Call security\n• Accident: Call 911 first\n\nMoving Issues:\n• Truck breakdown: Dispatch available\n• Delayed delivery: Track online\n• Damaged items: File claim immediately"
    ]
];

// Greeting responses
$greetings = [
    'hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'greetings'
];

$greeting_responses = [
    "Hello! 👋 How can I help you with parking or moving services today?",
    "Hi there! 🚗📦 What would you like to know about our services?",
    "Welcome! How can I assist you with parking or moving today?",
    "Hey! 👋 Ready to help with any parking or moving questions!"
];

// Fallback responses
$fallback_responses = [
    "I'm not sure about that. Here's what I can help with:\n• Parking rates and hours\n• Reservations and booking\n• Moving services and costs\n• Packing and storage\n• Contact information\n\nWhat would you like to know?",
    "I don't have that information yet. Try asking about:\n💰 Parking rates\n📦 Moving costs\n📍 Location hours\n📞 Contact info",
    "I'm still learning! Could you rephrase your question? Or try asking about parking or moving services.",
    "That's beyond my current knowledge. Would you like to speak with a human representative? Call (555) 123-4567"
];

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);
$message = strtolower(trim($input['message'] ?? ''));
$session_id = $input['session_id'] ?? session_id();

if (empty($message)) {
    echo json_encode(['response' => 'Please ask a question about our parking or moving services.']);
    exit;
}

// Function to check if message is a greeting
function isGreeting($message) {
    global $greetings;
    foreach ($greetings as $greeting) {
        if (strpos($message, $greeting) !== false) {
            return true;
        }
    }
    return false;
}

// Function to find best matching response
function findResponse($message) {
    global $faq_responses, $greeting_responses, $fallback_responses;
    
    // Check for greeting first
    if (isGreeting($message)) {
        return $greeting_responses[array_rand($greeting_responses)];
    }
    
    // Split message into words
    $words = str_word_count($message, 1);
    $best_match = null;
    $highest_score = 0;
    
    // Check each FAQ for keyword matches
    foreach ($faq_responses as $faq) {
        $score = 0;
        foreach ($faq['keywords'] as $keyword) {
            // Check if keyword exists in message
            if (strpos($message, $keyword) !== false) {
                $score += 10; // Exact match gets higher score
            }
            
            // Check individual words for partial matches
            foreach ($words as $word) {
                if (strlen($word) > 2 && (strpos($keyword, $word) !== false || strpos($word, $keyword) !== false)) {
                    $score += 5;
                }
            }
        }
        
        if ($score > $highest_score) {
            $highest_score = $score;
            $best_match = $faq['response'];
        }
    }
    
    // Return best match or fallback
    if ($best_match && $highest_score > 5) {
        return $best_match;
    }
    
    return $fallback_responses[array_rand($fallback_responses)];
}

// Get response
$response = findResponse($message);

// Store conversation in session (optional)
if (!isset($_SESSION['conversations'])) {
    $_SESSION['conversations'] = [];
}
$_SESSION['conversations'][] = [
    'user' => $message,
    'bot' => $response,
    'time' => date('Y-m-d H:i:s')
];

// Keep only last 10 conversations
if (count($_SESSION['conversations']) > 10) {
    array_shift($_SESSION['conversations']);
}

echo json_encode(['response' => $response]);
?>