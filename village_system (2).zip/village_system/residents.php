<?php
require_once 'config.php';

// Handle Add/Edit/Delete
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $national_id = $conn->real_escape_string($_POST['national_id']);
            $full_name = $conn->real_escape_string($_POST['full_name']);
            $gender = $conn->real_escape_string($_POST['gender']);
            $dob = $conn->real_escape_string($_POST['date_of_birth']);
            $phone = $conn->real_escape_string($_POST['phone']);
            $email = $conn->real_escape_string($_POST['email']);
            $village = $conn->real_escape_string($_POST['village']);
            $sub_location = $conn->real_escape_string($_POST['sub_location']);
            $occupation = $conn->real_escape_string($_POST['occupation']);
            $family_members = intval($_POST['family_members']);
            $household_head = $conn->real_escape_string($_POST['household_head']);
            
            $sql = "INSERT INTO residents (national_id, full_name, gender, date_of_birth, phone, email, village, sub_location, occupation, family_members, household_head) 
                    VALUES ('$national_id', '$full_name', '$gender', '$dob', '$phone', '$email', '$village', '$sub_location', '$occupation', '$family_members', '$household_head')";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Resident added successfully";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['message_type'] = "danger";
            }
            header("Location: residents.php");
            exit();
        }
        
        elseif ($action == 'edit') {
            $id = intval($_POST['id']);
            $full_name = $conn->real_escape_string($_POST['full_name']);
            $phone = $conn->real_escape_string($_POST['phone']);
            $email = $conn->real_escape_string($_POST['email']);
            $village = $conn->real_escape_string($_POST['village']);
            $sub_location = $conn->real_escape_string($_POST['sub_location']);
            $occupation = $conn->real_escape_string($_POST['occupation']);
            $family_members = intval($_POST['family_members']);
            
            $sql = "UPDATE residents SET full_name='$full_name', phone='$phone', email='$email', 
                    village='$village', sub_location='$sub_location', occupation='$occupation', family_members=$family_members 
                    WHERE id=$id";
            
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Resident updated successfully";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['message_type'] = "danger";
            }
            header("Location: residents.php");
            exit();
        }
        
        elseif ($action == 'delete') {
            $id = intval($_POST['id']);
            $sql = "DELETE FROM residents WHERE id=$id";
            if ($conn->query($sql)) {
                $_SESSION['message'] = "Resident deleted successfully";
                $_SESSION['message_type'] = "success";
            } else {
                $_SESSION['message'] = "Error: " . $conn->error;
                $_SESSION['message_type'] = "danger";
            }
            header("Location: residents.php");
            exit();
        }
    }
}

// Get search parameter
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$search_condition = "";
if (!empty($search)) {
    $search_condition = "WHERE full_name LIKE '%$search%' OR national_id LIKE '%$search%' OR phone LIKE '%$search%' OR village LIKE '%$search%' OR occupation LIKE '%$search%' OR sub_location LIKE '%$search%'";
}

// Get all residents with search filter
$residents = $conn->query("SELECT * FROM residents $search_condition ORDER BY registration_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Residents - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .navbar { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); padding: 15px; }
        .navbar-brand, .nav-link { color: white !important; }
        .nav-link:hover { opacity: 0.9; }
        .btn-custom { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); border: none; color: white; }
        .btn-custom:hover { transform: translateY(-2px); }
        .search-box { max-width: 400px; }
        footer { background: #2c3e50; color: white; padding: 20px 0; margin-top: 50px; }
        .clear-search { text-decoration: none; }
        .clear-search:hover { text-decoration: underline; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-village"></i> <?php echo SITE_NAME; ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link active" href="residents.php">Residents</a></li>
                <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="communications.php">Announcements</a></li>
                <li class="nav-item"><a class="nav-link" href="feedback.php">Feedback</a></li>
                <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Page</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h2><i class="fas fa-users me-2"></i>Residents Directory</h2>
        <div class="d-flex gap-2">
            <form method="GET" action="" class="d-flex gap-2">
                <div class="input-group search-box">
                    <input type="text" name="search" class="form-control" placeholder="Search by name, ID, phone, village..." value="<?php echo htmlspecialchars($search); ?>">
                    <button class="btn btn-custom" type="submit"><i class="fas fa-search"></i> Search</button>
                </div>
                <?php if(!empty($search)): ?>
                    <a href="residents.php" class="btn btn-secondary"><i class="fas fa-times"></i> Clear</a>
                <?php endif; ?>
            </form>
            <button class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#addResidentModal">
                <i class="fas fa-plus"></i> Add New Resident
            </button>
        </div>
    </div>
    
    <?php display_message(); ?>
    
    <?php if(!empty($search)): ?>
        <div class="alert alert-info">
            <i class="fas fa-search"></i> Showing results for: <strong><?php echo htmlspecialchars($search); ?></strong>
            <?php if($residents->num_rows == 0): ?>
                <br>No residents found matching your search.
            <?php else: ?>
                <br>Found <strong><?php echo $residents->num_rows; ?></strong> resident(s).
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>National ID</th>
                            <th>Full Name</th>
                            <th>Gender</th>
                            <th>Phone</th>
                            <th>Village</th>
                            <th>Family</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($residents->num_rows > 0): ?>
                            <?php while($row = $residents->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['national_id']; ?></td>
                                <td><?php echo $row['full_name']; ?></td>
                                <td><?php echo $row['gender']; ?></td>
                                <td><?php echo $row['phone']; ?></td>
                                <td><?php echo $row['village']; ?></td>
                                <td><?php echo $row['family_members']; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info edit-resident" 
                                        data-id="<?php echo $row['id']; ?>"
                                        data-name="<?php echo $row['full_name']; ?>"
                                        data-phone="<?php echo $row['phone']; ?>"
                                        data-email="<?php echo $row['email']; ?>"
                                        data-village="<?php echo $row['village']; ?>"
                                        data-sublocation="<?php echo $row['sub_location']; ?>"
                                        data-occupation="<?php echo $row['occupation']; ?>"
                                        data-family="<?php echo $row['family_members']; ?>">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-resident" data-id="<?php echo $row['id']; ?>" data-name="<?php echo $row['full_name']; ?>">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">
                                    <i class="fas fa-search fa-2x mb-2 d-block"></i>
                                    No residents found. 
                                    <?php if(!empty($search)): ?>
                                        Try a different search term or <a href="residents.php">view all residents</a>.
                                    <?php else: ?>
                                        Click "Add New Resident" to get started.
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Resident Modal -->
<div class="modal fade" id="addResidentModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Add New Resident</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label>National ID *</label><input type="text" name="national_id" class="form-control" required></div>
                        <div class="col-md-6 mb-3"><label>Full Name *</label><input type="text" name="full_name" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Gender *</label><select name="gender" class="form-control" required><option>Male</option><option>Female</option></select></div>
                        <div class="col-md-4 mb-3"><label>Date of Birth *</label><input type="date" name="date_of_birth" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Phone *</label><input type="text" name="phone" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Email</label><input type="email" name="email" class="form-control"></div>
                        <div class="col-md-4 mb-3"><label>Village *</label><input type="text" name="village" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Sub-location</label><input type="text" name="sub_location" class="form-control"></div>
                        <div class="col-md-6 mb-3"><label>Occupation</label><input type="text" name="occupation" class="form-control"></div>
                        <div class="col-md-6 mb-3"><label>Family Members</label><input type="number" name="family_members" class="form-control" value="1"></div>
                        <div class="col-md-6 mb-3"><label>Household Head</label><input type="text" name="household_head" class="form-control"></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-custom">Save Resident</button>
                </div>
            </form>
        </div>
    </div>
</div>

<footer>
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Narok County, Kenya</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.edit-resident').forEach(btn => {
    btn.addEventListener('click', function() {
        const id = this.dataset.id, name = this.dataset.name, phone = this.dataset.phone, email = this.dataset.email;
        const village = this.dataset.village, sublocation = this.dataset.sublocation, occupation = this.dataset.occupation, family = this.dataset.family;
        
        const modalHtml = `<div class="modal fade" id="editModal"><div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header bg-primary text-white"><h5 class="modal-title">Edit Resident</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="${id}"><div class="mb-3"><label>Full Name</label><input type="text" name="full_name" class="form-control" value="${name}" required></div><div class="mb-3"><label>Phone</label><input type="text" name="phone" class="form-control" value="${phone}" required></div><div class="mb-3"><label>Email</label><input type="email" name="email" class="form-control" value="${email}"></div><div class="mb-3"><label>Village</label><input type="text" name="village" class="form-control" value="${village}" required></div><div class="mb-3"><label>Sub-location</label><input type="text" name="sub_location" class="form-control" value="${sublocation}"></div><div class="mb-3"><label>Occupation</label><input type="text" name="occupation" class="form-control" value="${occupation}"></div><div class="mb-3"><label>Family Members</label><input type="number" name="family_members" class="form-control" value="${family}"></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-custom">Update</button></div></form></div></div></div>`;
        if(document.getElementById('editModal')) document.getElementById('editModal').remove();
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        new bootstrap.Modal(document.getElementById('editModal')).show();
        document.getElementById('editModal').addEventListener('hidden.bs.modal', function(){ this.remove(); });
    });
});

document.querySelectorAll('.delete-resident').forEach(btn => {
    btn.addEventListener('click', function() {
        if(confirm(`Delete ${this.dataset.name}?`)) {
            const form = document.createElement('form'); form.method = 'POST';
            form.innerHTML = `<input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${this.dataset.id}">`;
            document.body.appendChild(form); form.submit();
        }
    });
});
</script>
</body>
</html>