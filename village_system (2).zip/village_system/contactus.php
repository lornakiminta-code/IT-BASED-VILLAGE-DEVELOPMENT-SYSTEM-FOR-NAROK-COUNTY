<?php
// ============================================================
// CONTACT US FORM WITH DATABASE DISPLAY - contactusform.php
// Retrieves and displays all contact messages from database
// Table: contactss (without phone, status, created_at)
// ============================================================

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'village_db';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass);

// Create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS $db_name");
$conn->select_db($db_name);

// Create contactss table if not exists (without phone, status, created_at)
$conn->query("
CREATE TABLE IF NOT EXISTS contactss (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL
)");

// Insert sample data if empty
$check = $conn->query("SELECT COUNT(*) as c FROM contactss");
$count = $check->fetch_assoc();
if ($count['c'] == 0) {
    $conn->query("INSERT INTO contactss (name, email, subject, message) VALUES 
        ('John Otieno', 'john@email.com', 'Village Project Inquiry', 'I would like to know more about the village development projects in my area.'),
        ('Mary Wanjiku', 'mary@email.com', 'Partnership Request', 'We are an NGO interested in partnering with VillageDev to expand digital literacy programs.'),
        ('Peter Kamau', 'peter@email.com', 'Technical Support', 'I need assistance with accessing the e-learning platform. Kindly guide me.'),
        ('Sarah Achieng', 'sarah@email.com', 'Feedback', 'The mobile services are very helpful. We appreciate your work in our village.'),
        ('James Mwangi', 'james@email.com', 'New Village Registration', 'We would like to register our village for the development program. Please share requirements.')
    ");
}

// Handle form submission
$message = '';
$message_type = '';
$form_data = ['name' => '', 'email' => '', 'subject' => '', 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_contact'])) {
    // Sanitize inputs
    $name = trim(htmlspecialchars($_POST['name']));
    $email = trim(filter_var($_POST['email'], FILTER_SANITIZE_EMAIL));
    $subject = trim(htmlspecialchars($_POST['subject']));
    $message_text = trim(htmlspecialchars($_POST['message']));
    
    $form_data = ['name' => $name, 'email' => $email, 'subject' => $subject, 'message' => $message_text];
    
    // Validation
    $errors = [];
    if (empty($name)) $errors[] = 'Name is required.';
    if (empty($email)) $errors[] = 'Email is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email format.';
    if (empty($message_text)) $errors[] = 'Message is required.';
    if (strlen($message_text) < 10) $errors[] = 'Message must be at least 10 characters.';
    
    if (empty($errors)) {
        $sql = "INSERT INTO contactss (name, email, subject, message) 
                VALUES ('$name', '$email', '$subject', '$message_text')";
        
        if ($conn->query($sql)) {
            $message = '✅ Your message has been sent successfully!';
            $message_type = 'success';
            $form_data = ['name' => '', 'email' => '', 'subject' => '', 'message' => ''];
        } else {
            $message = '❌ Failed to send message. Please try again.';
            $message_type = 'danger';
        }
    } else {
        $message = '⚠️ ' . implode(' ', $errors);
        $message_type = 'danger';
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM contactss WHERE id = $id");
    $message = '✅ Message deleted successfully!';
    $message_type = 'success';
}

// Fetch all contacts from database
$contacts_result = $conn->query("SELECT * FROM contactss ORDER BY id DESC");

// Count statistics
$total = $conn->query("SELECT COUNT(*) as c FROM contactss")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | VillageDev</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2D6A4F;
            --primary-dark: #1B4332;
            --primary-light: #40916C;
            --secondary: #52B788;
            --dark: #0D1F1A;
        }
        
        * {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #f0f7f4;
            min-height: 100vh;
            padding: 20px;
        }
        
        .container-custom {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* ===== HEADER ===== */
        .header-section {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            padding: 40px 0 30px;
            border-radius: 20px 20px 0 0;
            color: #fff;
            text-align: center;
        }
        .header-section h1 {
            font-weight: 800;
            font-size: 2.2rem;
        }
        .header-section p {
            opacity: 0.85;
            font-size: 1.05rem;
        }
        
        /* ===== STATS CARDS ===== */
        .stats-card {
            background: #fff;
            border-radius: 16px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            transition: all 0.3s ease;
            height: 100%;
        }
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }
        .stats-card h3 {
            font-weight: 800;
            color: var(--primary);
            font-size: 2rem;
        }
        .stats-card p {
            color: #6c7a7a;
            font-size: 0.9rem;
            margin: 0;
        }
        .stats-card i {
            font-size: 2rem;
            color: var(--secondary);
            margin-bottom: 10px;
        }
        
        /* ===== FORM ===== */
        .form-card {
            background: #fff;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.06);
        }
        .form-card h4 {
            font-weight: 700;
            color: var(--dark);
        }
        .form-card .form-control {
            border: 2px solid #e8edec;
            border-radius: 12px;
            padding: 12px 18px;
            transition: all 0.3s ease;
        }
        .form-card .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(45, 106, 79, 0.1);
        }
        .form-card .btn-submit {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
            border-radius: 12px;
            padding: 14px 35px;
            font-weight: 600;
            color: #fff;
            transition: all 0.3s ease;
            width: 100%;
        }
        .form-card .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(45, 106, 79, 0.3);
        }
        
        /* ===== TABLE ===== */
        .table-card {
            background: #fff;
            border-radius: 16px;
            padding: 25px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.06);
        }
        .table-card .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .table-card .table-header h5 {
            font-weight: 700;
            color: var(--dark);
        }
        .table-card .table {
            margin-bottom: 0;
        }
        .table-card .table th {
            background: #f8faf9;
            font-weight: 600;
            color: var(--dark);
            border-bottom: 2px solid #e8edec;
        }
        .table-card .table td {
            vertical-align: middle;
        }
        .table-card .table .message-preview {
            max-width: 250px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .table-card .table .btn-sm {
            padding: 4px 10px;
            font-size: 0.75rem;
        }
        .table-card .table tr:hover {
            background: #f8faf9;
        }
        
        /* ===== ALERT ===== */
        .alert-custom {
            border-radius: 12px;
            padding: 15px 20px;
            border: none;
            font-weight: 500;
        }
        .alert-custom.alert-success {
            background: #d4edda;
            color: #155724;
        }
        .alert-custom.alert-danger {
            background: #f8d7da;
            color: #721c24;
        }
        .alert-custom.alert-warning {
            background: #fff3cd;
            color: #856404;
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .header-section h1 {
                font-size: 1.6rem;
            }
            .table-card .table-responsive {
                font-size: 0.85rem;
            }
            .table-card .table .message-preview {
                max-width: 100px;
            }
            .form-card {
                padding: 20px;
            }
        }
        @media (max-width: 576px) {
            .header-section {
                padding: 25px 0 20px;
            }
            .header-section h1 {
                font-size: 1.3rem;
            }
            .stats-card h3 {
                font-size: 1.5rem;
            }
            .table-card {
                padding: 15px;
            }
            .table-card .table .message-preview {
                max-width: 60px;
            }
        }
        
        /* ===== SEARCH ===== */
        .search-box {
            border: 2px solid #e8edec;
            border-radius: 12px;
            padding: 8px 16px;
            transition: all 0.3s ease;
            max-width: 300px;
        }
        .search-box:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(45, 106, 79, 0.1);
        }
        
        /* ===== ID BADGE ===== */
        .id-badge {
            background: var(--primary);
            color: #fff;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.8rem;
        }
    </style>
</head>
<body>

<div class="container-custom">

    <!-- ===== HEADER ===== -->
    <div class="header-section">
        <h1><i class="fas fa-envelope me-3"></i> Contact Management</h1>
        <p>View all contact messages and send new inquiries</p>
    </div>

    <!-- ===== STATISTICS ===== -->
    <div class="row g-3 mt-4">
        <div class="col-md-4 col-6">
            <div class="stats-card">
                <i class="fas fa-envelope"></i>
                <h3><?php echo $total; ?></h3>
                <p>Total Messages</p>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stats-card">
                <i class="fas fa-users"></i>
                <h3><?php 
                    $unique = $conn->query("SELECT COUNT(DISTINCT email) as c FROM contactss")->fetch_assoc()['c'];
                    echo $unique; 
                ?></h3>
                <p>Unique Senders</p>
            </div>
        </div>
        <div class="col-md-4 col-6">
            <div class="stats-card">
                <i class="fas fa-file-alt"></i>
                <h3><?php 
                    $subjects = $conn->query("SELECT COUNT(DISTINCT subject) as c FROM contactss WHERE subject IS NOT NULL AND subject != ''")->fetch_assoc()['c'];
                    echo $subjects; 
                ?></h3>
                <p>Topics Discussed</p>
            </div>
        </div>
    </div>

    <!-- ===== MESSAGES ===== -->
    <?php if ($message): ?>
        <div class="alert alert-custom alert-<?php echo $message_type; ?> mt-4">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- ===== FORM + TABLE ===== -->
    
              
        <!-- RIGHT: TABLE OF CONTACTS -->
        <div class="col-lg-7">
            <div class="table-card">
                <div class="table-header">
                    <h5><i class="fas fa-list me-2" style="color: var(--primary);"></i> All Messages (<?php echo $total; ?>)</h5>
                    <div>
                        <input type="text" id="searchTable" class="search-box" placeholder="Search messages..." onkeyup="searchMessages()">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover" id="contactsTable">
                        <thead>
                            <tr>
                                <th style="width: 50px;">#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th style="width: 80px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($contacts_result && $contacts_result->num_rows > 0): ?>
                                <?php $count = 1; while ($row = $contacts_result->fetch_assoc()): ?>
                                    <tr>
                                        <td><span class="id-badge"><?php echo $count++; ?></span></td>
                                        <td><strong><?php echo htmlspecialchars($row['name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><?php echo htmlspecialchars($row['subject'] ?: 'N/A'); ?></td>
                                        <td class="message-preview" title="<?php echo htmlspecialchars($row['message']); ?>">
                                            <?php echo htmlspecialchars(substr($row['message'], 0, 60)) . (strlen($row['message']) > 60 ? '...' : ''); ?>
                                        </td>
                                        <td>
                                            <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" 
                                               onclick="return confirm('Are you sure you want to delete this message?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        <i class="fas fa-inbox fa-2x d-block mb-2"></i>
                                        No messages found. Be the first to send a message!
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Database info -->
                <div class="mt-3 pt-2 border-top text-muted small">
                    <i class="fas fa-database me-1"></i> 
                    Database: <strong>village_db</strong> | Table: <strong>contactss</strong> | 
                    Total Records: <strong><?php echo $total; ?></strong>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== FOOTER ===== -->
    <div class="text-center text-muted small mt-4 pb-3">
        &copy; <?php echo date('Y'); ?> VillageDev - IT-Based Village Development System
    </div>

</div>

<script>
    // ===== SEARCH FUNCTION =====
    function searchMessages() {
        var input = document.getElementById('searchTable');
        var filter = input.value.toUpperCase();
        var table = document.getElementById('contactsTable');
        var rows = table.getElementsByTagName('tr');
        
        for (var i = 1; i < rows.length; i++) {
            var cells = rows[i].getElementsByTagName('td');
            var found = false;
            for (var j = 1; j < cells.length - 1; j++) {
                if (cells[j]) {
                    var text = cells[j].textContent || cells[j].innerText;
                    if (text.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                        break;
                    }
                }
            }
            rows[i].style.display = found ? '' : 'none';
        }
    }

    // ===== AUTO-DISMISS ALERTS =====
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert-custom');
        alerts.forEach(function(alert) {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.style.display = 'none';
            }, 500);
        });
    }, 5000);
</script>

</body>
</html>
<?php
$conn->close();
?>