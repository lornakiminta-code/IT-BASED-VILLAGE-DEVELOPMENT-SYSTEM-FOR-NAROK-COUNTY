<?php
require_once 'config.php';

$total_residents = $conn->query("SELECT COUNT(*) as total FROM residents")->fetch_assoc()['total'];
$male_residents = $conn->query("SELECT COUNT(*) as total FROM residents WHERE gender='Male'")->fetch_assoc()['total'];
$female_residents = $conn->query("SELECT COUNT(*) as total FROM residents WHERE gender='Female'")->fetch_assoc()['total'];

$total_projects = $conn->query("SELECT COUNT(*) as total FROM projects")->fetch_assoc()['total'];
$completed_projects = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status='Completed'")->fetch_assoc()['total'];
$ongoing_projects = $conn->query("SELECT COUNT(*) as total FROM projects WHERE status='Ongoing'")->fetch_assoc()['total'];
$total_budget = $conn->query("SELECT SUM(budget) as total FROM projects")->fetch_assoc()['total'];

$village_stats = $conn->query("SELECT village, COUNT(*) as total FROM residents GROUP BY village ORDER BY total DESC");
$project_type_stats = $conn->query("SELECT project_type, COUNT(*) as total FROM projects GROUP BY project_type");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #f0f2f5; }
        .navbar { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); padding: 15px; }
        .navbar-brand, .nav-link { color: white !important; }
        .report-card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 20px; }
        footer { background: #2c3e50; color: white; padding: 20px 0; margin-top: 50px; }
        @media print { .navbar, .btn, .no-print { display: none !important; } }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top no-print">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-village"></i> <?php echo SITE_NAME; ?></a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="residents.php">Residents</a></li>
                <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="communications.php">Announcements</a></li>
                <li class="nav-item"><a class="nav-link" href="feedback.php">Feedback</a></li>
                <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Page</a></li>
                <li class="nav-item"><a class="nav-link active" href="reports.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container py-4" id="reportContent">
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <h2><i class="fas fa-chart-bar me-2"></i>Village Development Reports</h2>
        <button onclick="window.print()" class="btn btn-custom"><i class="fas fa-print"></i> Print Report</button>
    </div>
    
    <div class="text-center mb-5">
        <h3><?php echo SITE_NAME; ?></h3>
        <h4>Narok County, Kenya</h4>
        <p>Report Generated: <?php echo date('F j, Y H:i:s'); ?></p>
        <hr>
    </div>
    
    <!-- Population Statistics -->
    <div class="card report-card">
        <div class="card-header bg-white"><h5><i class="fas fa-users"></i> Population Statistics</h5></div>
        <div class="card-body">
            <div class="row text-center mb-4">
                <div class="col-md-4"><h3><?php echo $total_residents; ?></h3><p>Total Residents</p></div>
                <div class="col-md-4"><h3><?php echo $male_residents; ?></h3><p>Male</p></div>
                <div class="col-md-4"><h3><?php echo $female_residents; ?></h3><p>Female</p></div>
            </div>
            <canvas id="genderChart" height="80"></canvas>
        </div>
    </div>
    
    <!-- Village Distribution -->
    <div class="card report-card">
        <div class="card-header bg-white"><h5><i class="fas fa-map-marker-alt"></i> Village Population Distribution</h5></div>
        <div class="card-body">
            <table class="table">
                <thead><tr><th>Village</th><th>Population</th><th>Percentage</th></tr></thead>
                <tbody><?php while($v = $village_stats->fetch_assoc()): ?>
                <tr><td><?php echo $v['village']; ?></td><td><?php echo $v['total']; ?></td><td><?php echo round(($v['total']/$total_residents)*100, 1); ?>%</td></tr>
                <?php endwhile; ?></tbody>
            </table>
        </div>
    </div>
    
    <!-- Project Statistics -->
    <div class="card report-card">
        <div class="card-header bg-white"><h5><i class="fas fa-project-diagram"></i> Project Statistics</h5></div>
        <div class="card-body">
            <div class="row text-center mb-4">
                <div class="col-md-4"><h3><?php echo $total_projects; ?></h3><p>Total Projects</p></div>
                <div class="col-md-4"><h3><?php echo $ongoing_projects; ?></h3><p>Ongoing</p></div>
                <div class="col-md-4"><h3><?php echo $completed_projects; ?></h3><p>Completed</p></div>
            </div>
            <canvas id="projectChart" height="80"></canvas>
        </div>
    </div>
    
    <!-- Project Type Distribution -->
    <div class="card report-card">
        <div class="card-header bg-white"><h5><i class="fas fa-chart-pie"></i> Projects by Type</h5></div>
        <div class="card-body">
            <canvas id="typeChart" height="80"></canvas>
        </div>
    </div>
    
    <div class="text-center mt-5 pt-5"><small><?php echo SITE_NAME; ?> - Empowering Rural Development through Technology</small></div>
</div>

<footer class="no-print">
    <div class="container text-center"><p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Narok County, Kenya</p></div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
new Chart(document.getElementById('genderChart'), { type: 'pie', data: { labels: ['Male', 'Female'], datasets: [{ data: [<?php echo $male_residents; ?>, <?php echo $female_residents; ?>], backgroundColor: ['#1a5f7a', '#159895'] }] } });
new Chart(document.getElementById('projectChart'), { type: 'bar', data: { labels: ['Ongoing', 'Completed', 'Planning'], datasets: [{ label: 'Projects', data: [<?php echo $ongoing_projects; ?>, <?php echo $completed_projects; ?>, <?php echo $total_projects - $ongoing_projects - $completed_projects; ?>], backgroundColor: ['#ffc107', '#28a745', '#17a2b8'] }] } });
new Chart(document.getElementById('typeChart'), { type: 'doughnut', data: { labels: [<?php 
    $labels = []; $data = []; 
    while($pt = $project_type_stats->fetch_assoc()) { $labels[] = "'".$pt['project_type']."'"; $data[] = $pt['total']; } 
    echo implode(',', $labels); 
?>], datasets: [{ data: [<?php echo implode(',', $data); ?>], backgroundColor: ['#1a5f7a', '#159895', '#28a745', '#ffc107', '#dc3545', '#17a2b8'] }] } });
</script>
</body>
</html>