<?php
function whatsapp_button($phone, $message = "Hello", $text = "Chat on WhatsApp", $class = "") {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    $message = urlencode($message);
    $url = "https://wa.me/{$phone}?text={$message}";
    
    return '
    <a href="' . $url . '" class="whatsapp-btn ' . $class . '" target="_blank" style="
        display: inline-flex;
        align-items: center;
        background: #25D366;
        color: white;
        text-decoration: none;
        padding: 12px 24px;
        border-radius: 25px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
    ">
        <i class="fab fa-whatsapp" style="margin-right: 8px; font-size: 1.2em;"></i>
        ' . $text . '
    </a>
    ';
}
?>

<!-- Usage Example -->
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .whatsapp-btn:hover {
            background: #128C7E !important;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <?php echo whatsapp_button("+254706795782", "Hello, I'm interested!", "Contact Us"); ?>
</body>
</html>