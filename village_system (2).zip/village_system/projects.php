<?php
require_once 'config.php';

// Handle Add Project
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        $project_code = $conn->real_escape_string($_POST['project_code']);
        $project_name = $conn->real_escape_string($_POST['project_name']);
        $project_type = $conn->real_escape_string($_POST['project_type']);
        $description = $conn->real_escape_string($_POST['description']);
        $location = $conn->real_escape_string($_POST['location']);
        $village = $conn->real_escape_string($_POST['village']);
        $budget = floatval($_POST['budget']);
        $start_date = $conn->real_escape_string($_POST['start_date']);
        $expected_end_date = $conn->real_escape_string($_POST['expected_end_date']);
        $contractor = $conn->real_escape_string($_POST['contractor']);
        $supervisor_name = $conn->real_escape_string($_POST['supervisor_name']);
        $status = $conn->real_escape_string($_POST['status']);
        
        $sql = "INSERT INTO projects (project_code, project_name, project_type, description, location, village, budget, start_date, expected_end_date, contractor, supervisor_name, status) 
                VALUES ('$project_code', '$project_name', '$project_type', '$description', '$location', '$village', $budget, '$start_date', '$expected_end_date', '$contractor', '$supervisor_name', '$status')";
        
        if ($conn->query($sql)) {
            $_SESSION['message'] = "Project added successfully";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Error: " . $conn->error;
            $_SESSION['message_type'] = "danger";
        }
        header("Location: projects.php");
        exit();
    }
    
    elseif ($action == 'update_progress') {
        $id = intval($_POST['id']);
        $progress = intval($_POST['progress']);
        $description = $conn->real_escape_string($_POST['description']);
        $amount_spent = floatval($_POST['amount_spent']);
        
        $conn->query("UPDATE projects SET progress=$progress WHERE id=$id");
        $sql = "INSERT INTO project_updates (project_id, update_date, progress_percentage, description, amount_spent) 
                VALUES ($id, CURDATE(), $progress, '$description', $amount_spent)";
        
        if ($conn->query($sql)) {
            $_SESSION['message'] = "Project progress updated successfully";
            $_SESSION['message_type'] = "success";
            if ($progress == 100) $conn->query("UPDATE projects SET status='Completed' WHERE id=$id");
        } else {
            $_SESSION['message'] = "Error: " . $conn->error;
            $_SESSION['message_type'] = "danger";
        }
        header("Location: projects.php");
        exit();
    }
}

$projects = $conn->query("SELECT * FROM projects ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        .navbar { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); padding: 15px; }
        .navbar-brand, .nav-link { color: white !important; }
        .btn-custom { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); border: none; color: white; }
        .btn-custom:hover { transform: translateY(-2px); }
        .project-card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 20px; transition: transform 0.3s; }
        .project-card:hover { transform: translateY(-5px); }
        footer { background: #2c3e50; color: white; padding: 20px 0; margin-top: 50px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-village"></i> <?php echo SITE_NAME; ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="residents.php">Residents</a></li>
                <li class="nav-item"><a class="nav-link active" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="communications.php">Announcements</a></li>
                <li class="nav-item"><a class="nav-link" href="feedback.php">Feedback</a></li>
                <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Page</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-project-diagram me-2"></i>Development Projects</h2>
        <button class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#addProjectModal">
            <i class="fas fa-plus"></i> Add New Project
        </button>
    </div>
    
    <?php display_message(); ?>
    
    <div class="row">
        <?php while($project = $projects->fetch_assoc()): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card project-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h5 class="card-title"><?php echo $project['project_name']; ?></h5>
                        <span class="badge bg-<?php echo $project['status'] == 'Completed' ? 'success' : ($project['status'] == 'Ongoing' ? 'primary' : 'warning'); ?>"><?php echo $project['status']; ?></span>
                    </div>
                    <p class="text-muted small">Code: <?php echo $project['project_code']; ?> | <?php echo $project['project_type']; ?></p>
                    <p class="card-text small"><?php echo substr($project['description'], 0, 100); ?>...</p>
                    <div class="mb-2">
                        <small>Progress: <?php echo $project['progress']; ?>%</small>
                        <div class="progress" style="height: 8px;"><div class="progress-bar" style="width: <?php echo $project['progress']; ?>%"></div></div>
                    </div>
                    <div class="row small mb-3">
                        <div class="col-6"><strong>Budget:</strong><br>KES <?php echo number_format($project['budget'], 0); ?></div>
                        <div class="col-6"><strong>Location:</strong><br><?php echo $project['village']; ?></div>
                    </div>
                    <button class="btn btn-sm btn-info w-100 update-project" 
                            data-id="<?php echo $project['id']; ?>" 
                            data-name="<?php echo $project['project_name']; ?>" 
                            data-progress="<?php echo $project['progress']; ?>">
                        <i class="fas fa-chart-line"></i> Update Progress
                    </button>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<!-- Add Project Modal -->
<div class="modal fade" id="addProjectModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Add New Project</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="row">
                        <div class="col-md-6 mb-3"><label>Project Code *</label><input type="text" name="project_code" class="form-control" required placeholder="NAROK-WTR-001"></div>
                        <div class="col-md-6 mb-3"><label>Project Name *</label><input type="text" name="project_name" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Project Type *</label><select name="project_type" class="form-control" required><option>Water</option><option>Roads</option><option>Schools</option><option>Health</option><option>Agriculture</option><option>Electricity</option></select></div>
                        <div class="col-md-4 mb-3"><label>Location *</label><input type="text" name="location" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Village *</label><input type="text" name="village" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Budget (KES) *</label><input type="number" name="budget" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Start Date *</label><input type="date" name="start_date" class="form-control" required></div>
                        <div class="col-md-4 mb-3"><label>Expected End Date</label><input type="date" name="expected_end_date" class="form-control"></div>
                        <div class="col-md-6 mb-3"><label>Contractor</label><input type="text" name="contractor" class="form-control"></div>
                        <div class="col-md-6 mb-3"><label>Supervisor</label><input type="text" name="supervisor_name" class="form-control"></div>
                        <div class="col-md-6 mb-3"><label>Status *</label><select name="status" class="form-control" required><option>Planning</option><option>Ongoing</option><option>Completed</option><option>On Hold</option></select></div>
                        <div class="col-12 mb-3"><label>Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-custom">Save Project</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Progress Modal -->
<div class="modal fade" id="updateProgressModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Update Project Progress</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_progress">
                    <input type="hidden" name="id" id="update_project_id">
                    <div class="mb-3"><label>Project Name</label><input type="text" id="update_project_name" class="form-control" readonly></div>
                    <div class="mb-3"><label>Current Progress (%)</label><input type="number" name="progress" id="update_progress" class="form-control" required min="0" max="100"></div>
                    <div class="mb-3"><label>Update Description</label><textarea name="description" class="form-control" rows="3" required></textarea></div>
                    <div class="mb-3"><label>Amount Spent (KES)</label><input type="number" name="amount_spent" class="form-control"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-custom">Update Progress</button>
                </div>
            </form>
        </div>
    </div>
</div>

<footer>
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Narok County, Kenya</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.update-project').forEach(btn => {
    btn.addEventListener('click', function() {
        document.getElementById('update_project_id').value = this.dataset.id;
        document.getElementById('update_project_name').value = this.dataset.name;
        document.getElementById('update_progress').value = this.dataset.progress;
        new bootstrap.Modal(document.getElementById('updateProgressModal')).show();
    });
});
</script>
</body>
</html>