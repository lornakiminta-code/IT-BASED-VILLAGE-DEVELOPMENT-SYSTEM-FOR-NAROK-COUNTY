<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required Meta Tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Page Title -->
    <title>EVENTS MANAGEMENT SYSTEM</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/logo/favicon.png" type="image/x-icon">
    <style>
        body {
            background-image: url('6.jpg'); /* Replace 'background_image.jpg' with the path to your image */
            background-size: cover;
            background-position: center;
        }
    </style>
    <!-- CSS Files -->
    <link rel="stylesheet" href="assets/css/animate-3.7.0.css">
    <link rel="stylesheet" href="assets/css/font-awesome-4.7.0.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-4.1.3.min.css">
    <link rel="stylesheet" href="assets/css/owl-carousel.min.css">
    <link rel="stylesheet" href="assets/css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" href="assets/css/linearicons.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
   
   
<head>
    <meta charset="UTF-8">
    <title>EVENTS MANAGEMENT SYSTEM</title>
</head>
<style>
    /* Add your CSS styles here */
</style>
<body onload="myFunction()">
    <div id="loader"></div>
    <div id="myDiv">
        
        <br>
        <div class="page-header foo">
            <h1 style="text-align: center;">OUR OFFICES LOCATION</h1>
        </div>
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <!-- Replace the iframe source with Kenyan map coordinates -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.154972998857!2d37.08017501430418!3d-1.0448106357040206!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f4ef517d2dd15%3A0x8e7d07383daf5916!2sMount%20Kenya%20University!5e0!3m2!1sen!2ske!4v1667904917370!5m2!1sen!2ske" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-md-3"></div>
    </div>

    <script>
        var myVar;

        // For fakeloader
        function myFunction() {
            // myVar = setTimeout(showPage, 1500);
        }

        function showPage() {
            // document.getElementById("loader").style.display = "none";
            // document.getElementById("myDiv").style.display = "block";
        }
    </script>

    <script src="https://unpkg.com/scrollreveal/dist/scrollreveal.min.js"></script>
    <script>
        window.sr = ScrollReveal();
        sr.reveal('.foo', { duration: 800 });
        sr.reveal('.foo1', { duration: 800,origin: 'top'});
    </script>
</body>
</html>
