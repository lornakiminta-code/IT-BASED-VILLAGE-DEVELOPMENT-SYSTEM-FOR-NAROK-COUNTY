<?php
require_once 'config.php';

if (!is_logged_in()) {
    redirect('index.php');
}

// Get statistics
$resident_count = $conn->query("SELECT COUNT(*) as count FROM residents")->fetch_assoc()['count'];
$project_count = $conn->query("SELECT COUNT(*) as count FROM projects")->fetch_assoc()['count'];
$ongoing_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status='Ongoing'")->fetch_assoc()['count'];
$completed_projects = $conn->query("SELECT COUNT(*) as count FROM projects WHERE status='Completed'")->fetch_assoc()['count'];
$feedback_count = $conn->query("SELECT COUNT(*) as count FROM feedback WHERE status='Pending'")->fetch_assoc()['count'];

// Get recent projects
$recent_projects = $conn->query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%);
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            border-radius: 8px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }
        .sidebar .nav-link i {
            margin-right: 10px;
        }
        .stat-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2.5rem;
            opacity: 0.3;
            position: absolute;
            right: 20px;
            top: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="text-center py-4">
                    <i class="fas fa-village fa-3x text-white"></i>
                    <h5 class="text-white mt-2">Village System</h5>
                    <small class="text-white-50">Welcome, <?php echo $_SESSION['user_name']; ?></small>
                </div>
                <nav class="nav flex-column px-3">
                    <a class="nav-link active" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    <a class="nav-link" href="residents.php"><i class="fas fa-users"></i> Residents</a>
                    <a class="nav-link" href="projects.php"><i class="fas fa-project-diagram"></i> Projects</a>
                    <a class="nav-link" href="communications.php"><i class="fas fa-bullhorn"></i> Communications</a>
                    <a class="nav-link" href="feedback.php"><i class="fas fa-comments"></i> Feedback</a>
                    <a class="nav-link" href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
                    <?php if($_SESSION['user_role'] == 'admin'): ?>
                    <a class="nav-link" href="admin/users.php"><i class="fas fa-user-cog"></i> User Management</a>
                    <?php endif; ?>
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </nav>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 p-4">
                <h2><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h2>
                <p class="text-muted">Welcome to <?php echo SITE_NAME; ?> - Narok County</p>
                
                <?php display_message(); ?>
                
                <!-- Statistics Cards -->
                <div class="row mt-4">
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body position-relative">
                                <h5 class="card-title text-muted">Total Residents</h5>
                                <h2 class="display-4"><?php echo $resident_count; ?></h2>
                                <i class="fas fa-users stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body position-relative">
                                <h5 class="card-title text-muted">Total Projects</h5>
                                <h2 class="display-4"><?php echo $project_count; ?></h2>
                                <i class="fas fa-project-diagram stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body position-relative">
                                <h5 class="card-title text-muted">Ongoing Projects</h5>
                                <h2 class="display-4"><?php echo $ongoing_projects; ?></h2>
                                <i class="fas fa-spinner stat-icon"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 mb-3">
                        <div class="card stat-card">
                            <div class="card-body position-relative">
                                <h5 class="card-title text-muted">Pending Feedback</h5>
                                <h2 class="display-4"><?php echo $feedback_count; ?></h2>
                                <i class="fas fa-envelope stat-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Projects -->
                <div class="card mt-4">
                    <div class="card-header bg-white">
                        <h5><i class="fas fa-clock me-2"></i>Recent Development Projects</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Project Code</th>
                                        <th>Project Name</th>
                                        <th>Type</th>
                                        <th>Budget</th>
                                        <th>Progress</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($project = $recent_projects->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $project['project_code']; ?></td>
                                        <td><?php echo $project['project_name']; ?></td>
                                        <td><?php echo $project['project_type']; ?></td>
                                        <td>KES <?php echo number_format($project['budget'], 2); ?></td>
                                        <td>
                                            <div class="progress" style="height: 8px;">
                                                <div class="progress-bar" style="width: <?php echo $project['progress']; ?>%"></div>
                                            </div>
                                            <small><?php echo $project['progress']; ?>%</small>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $project['status'] == 'Completed' ? 'success' : 
                                                    ($project['status'] == 'Ongoing' ? 'primary' : 
                                                    ($project['status'] == 'Planning' ? 'info' : 'warning')); 
                                            ?>">
                                                <?php echo $project['status']; ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>