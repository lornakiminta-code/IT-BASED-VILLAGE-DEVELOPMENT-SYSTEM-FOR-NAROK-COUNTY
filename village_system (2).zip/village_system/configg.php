<?php

// Database configuration
$servername = "localhost"; // Change this to your database server
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$database = "village_db"; // Change this to your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission for placing orders
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $amount = $_POST["amount"];
    $price = $_POST["price"];
    $weight = $_POST["weight"];
    $quantity = $_POST["quantity"];

    // Perform any necessary validation here

    // Insert order into database
    $query = "INSERT INTO orders (name, item, amount, price, weight, quantity) VALUES ('$name', '', '$amount', '$price', '$weight', '$quantity')";
    if (mysqli_query($conn, $query)) {
        echo "<p>Order placed successfully!</p>";
    } else {
        echo "<p>Error: " . mysqli_error($conn) . "</p>";
    }
}

?>
