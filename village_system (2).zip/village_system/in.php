<?php
// ============================================================
// IT-BASED VILLAGE DEVELOPMENT SYSTEM
// Complete system with Registration, Login, About, Services, Contact
// Database: village_db
// ============================================================

// Start session
session_start();

// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'village_db';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass);

// Create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS $db_name");
$conn->select_db($db_name);

// Create users table
$conn->query("
CREATE TABLE IF NOT EXISTS userss (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(200) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    village VARCHAR(100),
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create contacts table
$conn->query("
CREATE TABLE IF NOT EXISTS contactss (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(100) NOT NULL,
    subject VARCHAR(200),
    message TEXT NOT NULL,
    status ENUM('pending', 'read', 'replied') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Insert admin account if not exists
$check = $conn->query("SELECT * FROM userss WHERE email = 'admin@village.com'");
if ($check->num_rows == 0) {
    $admin_pass = password_hash('admin123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO userss (full_name, email, phone, village, password, role) VALUES 
        ('System Administrator', 'admin@village.com', '0712345678', 'Central Village', '$admin_pass', 'admin')");
}

// ============================================================
// AUTHENTICATION HANDLING
// ============================================================

// Registration
$reg_message = '';
$reg_type = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $village = trim($_POST['village']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($password !== $confirm_password) {
        $reg_message = 'Passwords do not match!';
        $reg_type = 'danger';
    } else {
        // Check if email already exists
        $check = $conn->query("SELECT * FROM userss WHERE email = '$email'");
        if ($check->num_rows > 0) {
            $reg_message = 'Email already registered!';
            $reg_type = 'danger';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO userss (full_name, email, phone, village, password) 
                    VALUES ('$full_name', '$email', '$phone', '$village', '$hashed_password')";
            if ($conn->query($sql)) {
                $reg_message = 'Registration successful! Please login.';
                $reg_type = 'success';
            } else {
                $reg_message = 'Registration failed. Please try again.';
                $reg_type = 'danger';
            }
        }
    }
}

// Login
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $result = $conn->query("SELECT * FROM userss WHERE email = '$email'");
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            header("Location: ?page=dashboard");
            exit();
        } else {
            $login_error = 'Invalid password!';
        }
    } else {
        $login_error = 'Email not found!';
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ?page=home");
    exit();
}

// Contact form
$contact_message = '';
$contact_type = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['contact'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);
    
    $sql = "INSERT INTO contactss (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
    if ($conn->query($sql)) {
        $contact_message = 'Your message has been sent successfully! We will get back to you soon.';
        $contact_type = 'success';
    } else {
        $contact_message = 'Failed to send message. Please try again.';
        $contact_type = 'danger';
    }
}

// Check if user is logged in
$is_logged_in = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
$current_page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT-Based Village Development System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2D6A4F;
            --primary-dark: #1B4332;
            --primary-light: #40916C;
            --secondary: #52B788;
            --accent: #D8F3DC;
            --dark: #0D1F1A;
            --light: #F8F9FA;
            --gradient-start: #2D6A4F;
            --gradient-end: #1B4332;
        }
        
        * {
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: #F0F7F4;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        /* ===== NAVBAR ===== */
        .navbar-custom {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            padding: 15px 0;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            position: sticky;
            top: 0;
            z-index: 1050;
        }
        .navbar-custom .navbar-brand {
            color: #fff;
            font-weight: 800;
            font-size: 1.4rem;
            letter-spacing: -0.5px;
        }
        .navbar-custom .navbar-brand i {
            color: var(--secondary);
            margin-right: 10px;
        }
        .navbar-custom .nav-link {
            color: rgba(255,255,255,0.85) !important;
            font-weight: 500;
            padding: 8px 18px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        .navbar-custom .nav-link:hover {
            color: #fff !important;
            background: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }
        .navbar-custom .nav-link.active {
            color: #fff !important;
            background: rgba(255,255,255,0.2);
        }
        .navbar-custom .nav-link i {
            margin-right: 6px;
        }
        .btn-logout {
            background: rgba(255,255,255,0.15);
            color: #fff;
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 25px;
            padding: 6px 20px;
            transition: all 0.3s ease;
        }
        .btn-logout:hover {
            background: #dc3545;
            border-color: #dc3545;
            color: #fff;
        }
        .user-badge {
            background: rgba(255,255,255,0.15);
            padding: 6px 16px;
            border-radius: 25px;
            color: #fff;
            font-size: 0.85rem;
        }
        .user-badge i {
            color: var(--secondary);
            margin-right: 6px;
        }
        
        /* ===== HERO ===== */
        .hero-section {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            padding: 80px 0 60px;
            color: #fff;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 500px;
            height: 500px;
            background: rgba(82, 183, 136, 0.15);
            border-radius: 50%;
        }
        .hero-section::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -10%;
            width: 400px;
            height: 400px;
            background: rgba(216, 243, 220, 0.08);
            border-radius: 50%;
        }
        .hero-section h1 {
            font-weight: 800;
            font-size: 3rem;
            letter-spacing: -1px;
            position: relative;
            z-index: 1;
        }
        .hero-section p {
            font-size: 1.15rem;
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }
        .hero-section .btn-hero {
            background: var(--secondary);
            color: var(--dark);
            font-weight: 600;
            padding: 12px 35px;
            border-radius: 50px;
            transition: all 0.3s ease;
            position: relative;
            z-index: 1;
        }
        .hero-section .btn-hero:hover {
            background: #fff;
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .hero-icon {
            font-size: 4rem;
            color: var(--secondary);
            position: relative;
            z-index: 1;
        }
        
        /* ===== CARDS ===== */
        .card-custom {
            border: none;
            border-radius: 16px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            overflow: hidden;
            height: 100%;
        }
        .card-custom:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 45px rgba(0,0,0,0.12);
        }
        .card-custom .card-body {
            padding: 30px;
        }
        .card-custom .icon-circle {
            width: 70px;
            height: 70px;
            background: linear-gradient(135deg, var(--primary-light), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: #fff;
            margin-bottom: 20px;
        }
        .card-custom h5 {
            font-weight: 700;
            color: var(--dark);
        }
        .card-custom p {
            color: #6c7a7a;
            font-size: 0.95rem;
        }
        
        /* ===== SECTION TITLES ===== */
        .section-title {
            font-weight: 800;
            color: var(--dark);
            letter-spacing: -0.5px;
        }
        .section-title span {
            color: var(--primary);
        }
        .section-subtitle {
            color: #6c7a7a;
            font-size: 1.05rem;
        }
        .title-line {
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 4px;
            margin: 15px auto 0;
        }
        
        /* ===== AUTH FORMS ===== */
        .auth-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 10px 50px rgba(0,0,0,0.08);
            overflow: hidden;
            background: #fff;
        }
        .auth-card .auth-header {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            padding: 30px;
            color: #fff;
            text-align: center;
        }
        .auth-card .auth-header h4 {
            font-weight: 700;
        }
        .auth-card .auth-body {
            padding: 35px;
        }
        .auth-card .form-control {
            border-radius: 12px;
            padding: 12px 18px;
            border: 2px solid #e8edec;
            transition: all 0.3s ease;
        }
        .auth-card .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(45, 106, 79, 0.1);
        }
        .auth-card .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border: none;
            border-radius: 12px;
            padding: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .auth-card .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(45, 106, 79, 0.3);
        }
        
        /* ===== SERVICES ===== */
        .service-card {
            background: #fff;
            border: none;
            border-radius: 16px;
            padding: 30px 25px;
            text-align: center;
            box-shadow: 0 5px 25px rgba(0,0,0,0.06);
            transition: all 0.3s ease;
            height: 100%;
        }
        .service-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }
        .service-card .service-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, rgba(45, 106, 79, 0.1), rgba(82, 183, 136, 0.1));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 2.5rem;
            color: var(--primary);
        }
        .service-card h5 {
            font-weight: 700;
            color: var(--dark);
        }
        .service-card p {
            color: #6c7a7a;
            font-size: 0.95rem;
        }
        
        /* ===== ABOUT ===== */
        .about-image {
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .about-image i {
            font-size: 8rem;
            color: var(--primary-light);
        }
        .stat-box {
            background: #fff;
            padding: 25px;
            border-radius: 16px;
            text-align: center;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }
        .stat-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .stat-box h3 {
            color: var(--primary);
            font-weight: 800;
        }
        .stat-box p {
            color: #6c7a7a;
            font-size: 0.9rem;
        }
        
        /* ===== CONTACT ===== */
        .contact-info {
            background: #fff;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }
        .contact-info:hover {
            transform: translateX(5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
        }
        .contact-info i {
            color: var(--primary);
            font-size: 1.5rem;
            margin-right: 15px;
        }
        
        /* ===== DASHBOARD ===== */
        .dashboard-stats {
            background: #fff;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            text-align: center;
            transition: all 0.3s ease;
        }
        .dashboard-stats:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .dashboard-stats h2 {
            color: var(--primary);
            font-weight: 800;
        }
        
        /* ===== FOOTER ===== */
        .footer {
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            color: rgba(255,255,255,0.85);
            padding: 50px 0 30px;
            margin-top: auto;
        }
        .footer h5 {
            color: #fff;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .footer a {
            color: rgba(255,255,255,0.75);
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .footer a:hover {
            color: var(--secondary);
        }
        .footer .social-icons a {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
            text-align: center;
            line-height: 40px;
            color: #fff;
            margin-right: 8px;
            transition: all 0.3s ease;
        }
        .footer .social-icons a:hover {
            background: var(--secondary);
            transform: translateY(-3px);
        }
        
        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            .hero-section h1 {
                font-size: 2rem;
            }
            .hero-section p {
                font-size: 1rem;
            }
            .auth-card .auth-body {
                padding: 20px;
            }
            .navbar-custom .navbar-brand {
                font-size: 1.1rem;
            }
            .footer {
                text-align: center;
            }
        }
        @media (max-width: 576px) {
            .hero-section {
                padding: 50px 0 40px;
            }
            .hero-section h1 {
                font-size: 1.7rem;
            }
            .section-title {
                font-size: 1.5rem;
            }
        }
        
        /* ===== ANIMATIONS ===== */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in-up {
            animation: fadeInUp 0.6s ease;
        }
    </style>
</head>
<body>

<!-- ============================================================ -->
<!-- NAVBAR -->
<!-- ============================================================ -->
<nav class="navbar navbar-custom navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="?page=home">
            <i class="fas fa-tree"></i> VillageDev
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'home') ? 'active' : ''; ?>" href="?page=home"><i class="fas fa-home"></i> Home</a></li>
                <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'about') ? 'active' : ''; ?>" href="?page=about"><i class="fas fa-info-circle"></i> About</a></li>
                <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'services') ? 'active' : ''; ?>" href="?page=services"><i class="fas fa-cogs"></i> Services</a></li>
                <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'contact') ? 'active' : ''; ?>" href="?page=contact"><i class="fas fa-envelope"></i> Contact</a></li>
                
                <?php if ($is_logged_in): ?>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'dashboard') ? 'active' : ''; ?>" href="?page=dashboard"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
                    <li class="nav-item ms-lg-2">
                        <span class="user-badge"><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a href="?logout=1" class="btn-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'login') ? 'active' : ''; ?>" href="?page=login"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'register') ? 'active' : ''; ?>" href="?page=register"><i class="fas fa-user-plus"></i> Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<!-- ============================================================ -->
<!-- PAGE CONTENT -->
<!-- ============================================================ -->
<div class="flex-grow-1">
    <?php if ($current_page == 'home' || $current_page == ''): ?>
        <!-- ===== HOME PAGE ===== -->
        <section class="hero-section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7">
                        <h1 class="mb-4">Empowering Villages Through <span style="color: var(--secondary);">Technology</span></h1>
                        <p class="mb-4">IT-Based Village Development System connects communities, streamlines services, and drives sustainable growth through innovative digital solutions.</p>
                        <div class="d-flex flex-wrap gap-3">
                            <a href="?page=register" class="btn btn-hero"><i class="fas fa-user-plus me-2"></i> Get Started</a>
                            <a href="?page=services" class="btn btn-outline-light btn-lg rounded-pill px-4">Explore Services</a>
                        </div>
                    </div>
                    <div class="col-lg-5 text-center mt-5 mt-lg-0">
                        <i class="fas fa-community hero-icon"></i>
                        <div class="row mt-4">
                            <div class="col-6">
                                <div class="bg-white bg-opacity-10 p-3 rounded-4">
                                    <h3 class="text-white">5+</h3>
                                    <p class="text-white-50 mb-0">Villages Connected</p>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="bg-white bg-opacity-10 p-3 rounded-4">
                                    <h3 class="text-white">200+</h3>
                                    <p class="text-white-50 mb-0">Active Users</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="container py-5">
            <!-- Features -->
            <div class="text-center mb-5">
                <h2 class="section-title">Why <span>VillageDev</span>?</h2>
                <p class="section-subtitle">Technology solutions designed for rural communities</p>
                <div class="title-line"></div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card-custom">
                        <div class="card-body">
                            <div class="icon-circle"><i class="fas fa-globe"></i></div>
                            <h5>Digital Connectivity</h5>
                            <p>Bridge the digital divide with accessible technology solutions for rural communities.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-custom">
                        <div class="card-body">
                            <div class="icon-circle"><i class="fas fa-hand-holding-heart"></i></div>
                            <h5>Community Empowerment</h5>
                            <p>Enable villagers to access services, information, and opportunities through technology.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-custom">
                        <div class="card-body">
                            <div class="icon-circle"><i class="fas fa-chart-line"></i></div>
                            <h5>Sustainable Growth</h5>
                            <p>Drive economic and social development through innovative digital solutions.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'about'): ?>
        <!-- ===== ABOUT PAGE ===== -->
        <div class="container py-5">
            <div class="text-center mb-5">
                <h2 class="section-title">About <span>Us</span></h2>
                <p class="section-subtitle">Our mission is to transform villages through technology</p>
                <div class="title-line"></div>
            </div>
            <div class="row align-items-center g-5">
                <div class="col-lg-6">
                    <div class="about-image bg-white p-5 text-center">
                        <i class="fas fa-tree"></i>
                        <h4 class="mt-3 text-primary">VillageDev Initiative</h4>
                        <p class="text-muted">Bridging technology and rural development</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h4 class="fw-bold">Our Story</h4>
                    <p class="text-muted">VillageDev was born from a vision to empower rural communities through information technology. We believe that every village deserves access to modern digital solutions that can transform lives.</p>
                    <p class="text-muted">Our team of passionate developers and community advocates work together to create sustainable technology solutions that address the unique needs of rural areas.</p>
                    <div class="row g-3 mt-4">
                        <div class="col-6"><div class="stat-box"><h3>5+</h3><p>Villages</p></div></div>
                        <div class="col-6"><div class="stat-box"><h3>200+</h3><p>Users</p></div></div>
                        <div class="col-6"><div class="stat-box"><h3>12+</h3><p>Projects</p></div></div>
                        <div class="col-6"><div class="stat-box"><h3>100%</h3><p>Commitment</p></div></div>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'services'): ?>
        <!-- ===== SERVICES PAGE ===== -->
        <div class="container py-5">
            <div class="text-center mb-5">
                <h2 class="section-title">Our <span>Services</span></h2>
                <p class="section-subtitle">Comprehensive digital solutions for village development</p>
                <div class="title-line"></div>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="service-card">
                        <div class="service-icon"><i class="fas fa-wifi"></i></div>
                        <h5>Digital Literacy</h5>
                        <p>Training programs to help villagers gain essential digital skills and access online resources.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <div class="service-icon"><i class="fas fa-mobile-alt"></i></div>
                        <h5>Mobile Services</h5>
                        <p>Mobile applications for accessing village services, information, and community updates.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <div class="service-icon"><i class="fas fa-database"></i></div>
                        <h5>Data Management</h5>
                        <p>Centralized systems for managing village resources, health records, and agricultural data.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <div class="service-icon"><i class="fas fa-handshake"></i></div>
                        <h5>Community Engagement</h5>
                        <p>Platforms for connecting community members, sharing ideas, and collaborative problem-solving.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <div class="service-icon"><i class="fas fa-tractor"></i></div>
                        <h5>Agricultural Tech</h5>
                        <p>Smart farming solutions including weather updates, market prices, and crop management tools.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="service-card">
                        <div class="service-icon"><i class="fas fa-graduation-cap"></i></div>
                        <h5>E-Learning</h5>
                        <p>Online education platforms providing access to quality learning resources for all ages.</p>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'contact'): ?>
        <!-- ===== CONTACT PAGE ===== -->
        <div class="container py-5">
            <div class="text-center mb-5">
                <h2 class="section-title">Contact <span>Us</span></h2>
                <p class="section-subtitle">We'd love to hear from you. Get in touch with our team.</p>
                <div class="title-line"></div>
            </div>
            <div class="row g-4">
                <div class="col-lg-5">
                    <div class="card-custom p-4">
                        <h5 class="fw-bold mb-4"><i class="fas fa-phone-alt text-primary me-2"></i> Get in Touch</h5>
                        <div class="contact-info"><i class="fas fa-map-marker-alt"></i> <div><strong>Location</strong><br>Nairobi, Kenya</div></div>
                        <div class="contact-info"><i class="fas fa-phone"></i> <div><strong>Phone</strong><br>+254 700 123 456</div></div>
                        <div class="contact-info"><i class="fas fa-envelope"></i> <div><strong>Email</strong><br>info@villagedev.com</div></div>
                        <div class="contact-info"><i class="fas fa-clock"></i> <div><strong>Working Hours</strong><br>Mon - Fri: 8:00 AM - 6:00 PM</div></div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5 class="fw-bold mb-3">Send Us a Message</h5>
                            <?php if ($contact_message): ?>
                                <div class="alert alert-<?php echo $contact_type; ?> alert-dismissible fade show">
                                    <?php echo $contact_message; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            <?php endif; ?>
                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3"><input type="text" name="name" class="form-control" placeholder="Your Name" required></div>
                                    <div class="col-md-6 mb-3"><input type="email" name="email" class="form-control" placeholder="Your Email" required></div>
                                    <div class="col-12 mb-3"><input type="text" name="subject" class="form-control" placeholder="Subject"></div>
                                    <div class="col-12 mb-3"><textarea name="message" class="form-control" rows="5" placeholder="Your Message" required></textarea></div>
                                    <div class="col-12"><button type="submit" name="contact" class="btn btn-primary btn-lg w-100"><i class="fas fa-paper-plane me-2"></i> Send Message</button></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'register'): ?>
        <!-- ===== REGISTER PAGE ===== -->
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="auth-card">
                        <div class="auth-header">
                            <i class="fas fa-user-plus fa-3x mb-3"></i>
                            <h4>Create Your Account</h4>
                            <p class="mb-0 opacity-75">Join VillageDev and be part of the digital revolution</p>
                        </div>
                        <div class="auth-body">
                            <?php if ($reg_message): ?>
                                <div class="alert alert-<?php echo $reg_type; ?> alert-dismissible fade show">
                                    <?php echo $reg_message; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            <?php endif; ?>
                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3"><input type="text" name="full_name" class="form-control" placeholder="Full Name" required></div>
                                    <div class="col-md-6 mb-3"><input type="email" name="email" class="form-control" placeholder="Email Address" required></div>
                                    <div class="col-md-6 mb-3"><input type="text" name="phone" class="form-control" placeholder="Phone Number"></div>
                                    <div class="col-md-6 mb-3"><input type="text" name="village" class="form-control" placeholder="Your Village"></div>
                                    <div class="col-md-6 mb-3"><input type="password" name="password" class="form-control" placeholder="Password" required></div>
                                    <div class="col-md-6 mb-3"><input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required></div>
                                </div>
                                <button type="submit" name="register" class="btn btn-primary w-100"><i class="fas fa-user-plus me-2"></i> Register</button>
                                <p class="text-center mt-3 text-muted">Already have an account? <a href="?page=login" class="text-primary fw-bold">Login here</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'login'): ?>
        <!-- ===== LOGIN PAGE ===== -->
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <div class="auth-card">
                        <div class="auth-header">
                            <i class="fas fa-sign-in-alt fa-3x mb-3"></i>
                            <h4>Welcome Back</h4>
                            <p class="mb-0 opacity-75">Login to access your VillageDev account</p>
                        </div>
                        <div class="auth-body">
                            <?php if ($login_error): ?>
                                <div class="alert alert-danger alert-dismissible fade show">
                                    <?php echo $login_error; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            <?php endif; ?>
                            <form method="POST">
                                <div class="mb-3"><input type="email" name="email" class="form-control" placeholder="Email Address" required></div>
                                <div class="mb-3"><input type="password" name="password" class="form-control" placeholder="Password" required></div>
                                <button type="submit" name="login" class="btn btn-primary w-100"><i class="fas fa-sign-in-alt me-2"></i> Login</button>
                                <p class="text-center mt-3 text-muted">Don't have an account? <a href="?page=register" class="text-primary fw-bold">Register here</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'dashboard' && $is_logged_in): ?>
        <!-- ===== DASHBOARD PAGE ===== -->
        <div class="container py-5">
            <div class="text-center mb-5">
                <h2 class="section-title">Welcome, <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span></h2>
                <p class="section-subtitle">Your VillageDev dashboard</p>
                <div class="title-line"></div>
            </div>
            
            <div class="row g-4 mb-5">
                <div class="col-md-3">
                    <div class="dashboard-stats">
                        <i class="fas fa-users fa-3x text-primary mb-2"></i>
                        <h2><?php echo $conn->query("SELECT COUNT(*) as c FROM userss")->fetch_assoc()['c']; ?></h2>
                        <p class="text-muted">Total Users</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-stats">
                        <i class="fas fa-envelope fa-3x text-primary mb-2"></i>
                        <h2><?php echo $conn->query("SELECT COUNT(*) as c FROM contactss")->fetch_assoc()['c']; ?></h2>
                        <p class="text-muted">Total Messages</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-stats">
                        <i class="fas fa-tree fa-3x text-primary mb-2"></i>
                        <h2>5</h2>
                        <p class="text-muted">Villages Connected</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="dashboard-stats">
                        <i class="fas fa-check-circle fa-3x text-primary mb-2"></i>
                        <h2>12</h2>
                        <p class="text-muted">Projects Completed</p>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-6">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5 class="fw-bold"><i class="fas fa-user me-2 text-primary"></i> Your Profile</h5>
                            <hr>
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['user_email']); ?></p>
                            <p><strong>Role:</strong> <span class="badge bg-primary"><?php echo htmlspecialchars($_SESSION['user_role']); ?></span></p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="card-custom">
                        <div class="card-body">
                            <h5 class="fw-bold"><i class="fas fa-bullhorn me-2 text-primary"></i> Quick Actions</h5>
                            <hr>
                            <div class="d-grid gap-2">
                                <a href="?page=services" class="btn btn-primary"><i class="fas fa-cogs me-2"></i> Explore Services</a>
                                <a href="?page=contact" class="btn btn-outline-primary"><i class="fas fa-envelope me-2"></i> Contact Support</a>
                                <a href="?page=home" class="btn btn-outline-secondary"><i class="fas fa-home me-2"></i> Home Page</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php elseif ($current_page == 'dashboard' && !$is_logged_in): ?>
        <div class="container py-5">
            <div class="alert alert-warning text-center">
                <i class="fas fa-exclamation-triangle me-2"></i> Please <a href="?page=login" class="fw-bold">login</a> to access the dashboard.
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- ============================================================ -->
<!-- FOOTER -->
<!-- ============================================================ -->
<footer class="footer">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <h5><i class="fas fa-tree me-2"></i> VillageDev</h5>
                <p class="opacity-75">IT-Based Village Development System empowering rural communities through innovative technology solutions.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-6">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="?page=home">Home</a></li>
                    <li><a href="?page=about">About</a></li>
                    <li><a href="?page=services">Services</a></li>
                    <li><a href="?page=contact">Contact</a></li>
                         <li><a href="login2.php">Admin</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-6">
                <h5>Services</h5>
                <ul class="list-unstyled">
                    <li><a href="?page=services">Digital Literacy</a></li>
                    <li><a href="?page=services">Mobile Services</a></li>
                    <li><a href="?page=services">Data Management</a></li>
                    <li><a href="?page=services">E-Learning</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h5>Contact Info</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt me-2"></i> Nairobi, Kenya</li>
                    <li><i class="fas fa-phone me-2"></i> +254 700 123 456</li>
                    <li><i class="fas fa-envelope me-2"></i> info@villagedev.com</li>
                </ul>
            </div>
        </div>
        <hr class="border-light opacity-25 my-4">
        <div class="text-center opacity-75">
            &copy; <?php echo date('Y'); ?> VillageDev - IT-Based Village Development System. All rights reserved.
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto-dismiss alerts
    setTimeout(function() {
        document.querySelectorAll('.alert').forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);
</script>
</body>
</html>
<?php
$conn->close();
?>