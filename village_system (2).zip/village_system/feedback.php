<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'respond') {
        $id = intval($_POST['id']);
        $response = $conn->real_escape_string($_POST['response']);
        $sql = "UPDATE feedback SET response='$response', status='Resolved', response_date=NOW() WHERE id=$id";
        if ($conn->query($sql)) {
            $_SESSION['message'] = "Response sent successfully";
            $_SESSION['message_type'] = "success";
        }
        header("Location: feedback.php");
        exit();
    }
    
    elseif (isset($_POST['action']) && $_POST['action'] == 'submit') {
        $resident_name = $conn->real_escape_string($_POST['resident_name']);
        $resident_phone = $conn->real_escape_string($_POST['resident_phone']);
        $subject = $conn->real_escape_string($_POST['subject']);
        $message = $conn->real_escape_string($_POST['message']);
        $type = $conn->real_escape_string($_POST['type']);
        
        $sql = "INSERT INTO feedback (resident_name, resident_phone, subject, message, type) 
                VALUES ('$resident_name', '$resident_phone', '$subject', '$message', '$type')";
        
        if ($conn->query($sql)) {
            $_SESSION['message'] = "Thank you! Your feedback has been submitted.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Error: " . $conn->error;
            $_SESSION['message_type'] = "danger";
        }
        header("Location: feedback.php");
        exit();
    }
}

$feedbacks = $conn->query("SELECT * FROM feedback ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .navbar { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); padding: 15px; }
        .navbar-brand, .nav-link { color: white !important; }
        .btn-custom { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); border: none; color: white; }
        .feedback-card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .status-pending { background: #ffc107; color: #000; padding: 3px 10px; border-radius: 20px; font-size: 12px; }
        .status-resolved { background: #28a745; color: white; padding: 3px 10px; border-radius: 20px; font-size: 12px; }
        footer { background: #2c3e50; color: white; padding: 20px 0; margin-top: 50px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-village"></i> <?php echo SITE_NAME; ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="residents.php">Residents</a></li>
                <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link" href="communications.php">Announcements</a></li>
                <li class="nav-item"><a class="nav-link active" href="feedback.php">Feedback</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="row">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-comment"></i> Submit Feedback</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="submit">
                        <div class="mb-3"><label>Your Name *</label><input type="text" name="resident_name" class="form-control" required></div>
                        <div class="mb-3"><label>Phone Number</label><input type="text" name="resident_phone" class="form-control"></div>
                        <div class="mb-3"><label>Feedback Type *</label><select name="type" class="form-control" required><option>Complaint</option><option>Suggestion</option><option>Inquiry</option><option>Appreciation</option></select></div>
                        <div class="mb-3"><label>Subject *</label><input type="text" name="subject" class="form-control" required></div>
                        <div class="mb-3"><label>Message *</label><textarea name="message" class="form-control" rows="5" required></textarea></div>
                        <button type="submit" class="btn btn-custom w-100">Submit Feedback <i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-7">
            <h5><i class="fas fa-list"></i> Recent Feedback</h5>
            <?php while($fb = $feedbacks->fetch_assoc()): ?>
            <div class="card feedback-card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div><strong><?php echo $fb['resident_name']; ?></strong> <span class="badge bg-secondary"><?php echo $fb['type']; ?></span> <span class="status-<?php echo strtolower($fb['status']); ?>"><?php echo $fb['status']; ?></span></div>
                        <small><?php echo date('M j, Y', strtotime($fb['created_at'])); ?></small>
                    </div>
                    <h6 class="mt-2"><?php echo $fb['subject']; ?></h6>
                    <p class="small"><?php echo nl2br($fb['message']); ?></p>
                    <?php if($fb['response']): ?>
                    <div class="bg-light p-2 rounded mt-2">
                        <strong><i class="fas fa-reply"></i> Response:</strong>
                        <p class="mb-0 small"><?php echo nl2br($fb['response']); ?></p>
                    </div>
                    <?php else: ?>
                    <button class="btn btn-sm btn-primary respond-btn" data-id="<?php echo $fb['id']; ?>" data-resident="<?php echo $fb['resident_name']; ?>" data-subject="<?php echo $fb['subject']; ?>"><i class="fas fa-reply"></i> Respond</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<!-- Respond Modal -->
<div class="modal fade" id="respondModal" tabindex="-1">
    <div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header bg-primary text-white"><h5 class="modal-title">Respond to Feedback</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="respond"><input type="hidden" name="id" id="respond_id"><div class="mb-3"><label>Resident</label><input type="text" id="respond_resident" class="form-control" readonly></div><div class="mb-3"><label>Subject</label><input type="text" id="respond_subject" class="form-control" readonly></div><div class="mb-3"><label>Your Response *</label><textarea name="response" class="form-control" rows="4" required></textarea></div></div><div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-custom">Send Response</button></div></form></div></div>
</div>

<footer>
    <div class="container text-center"><p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Narok County, Kenya</p></div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('.respond-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.getElementById('respond_id').value = this.dataset.id;
        document.getElementById('respond_resident').value = this.dataset.resident;
        document.getElementById('respond_subject').value = this.dataset.subject;
        new bootstrap.Modal(document.getElementById('respondModal')).show();
    });
});
</script>
</body>
</html>