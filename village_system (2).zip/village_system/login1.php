<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "ofrsdb");

if (isset($_POST['login'])) {
    $user_name = $_POST['user_name'];
    $pass_word = $_POST['pass_word'];
    $query = mysqli_query($con, "SELECT * FROM users WHERE user_name='$user_name' AND pass_word='$pass_word'");
    $row = mysqli_fetch_assoc($query);

    if ($row) {
        $_SESSION['name'] = $row['name'];
        header("Location: reporting.php");
        exit();
    } else {
        echo "<script>alert('Invalid credentials');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            background: #fce4ec;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            width: 350px;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.2);
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #d81b60;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #d81b60;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #c2185b;
        }

        p {
            margin-top: 15px;
            font-size: 14px;
        }

        a {
            color: #d81b60;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <form method="post">
            <input type="text" name="user_name" placeholder="Username" required>
            <input type="password" name="pass_word" placeholder="Password" required>
            <button type="submit" name="login">Login</button>
        </form>
        <p>Don't have an account? <a href="register.php">Register here</a>.</p>
    </div>
</body>
</html>
