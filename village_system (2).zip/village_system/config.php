<?php
// Database configuration
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'village_db';

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Site configuration
define('SITE_NAME', 'IT-Based Village Development System');
define('SITE_TAGLINE', 'Narok County - Digital Village Transformation');
define('BASE_URL', 'http://localhost/village_system/');

// Function to display success/error messages
function display_message() {
    if (isset($_SESSION['message'])) {
        echo '<div class="alert alert-' . $_SESSION['message_type'] . ' alert-dismissible fade show" role="alert">
                ' . $_SESSION['message'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
}

// Start session for messages only (not for login)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>