<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    $title = $conn->real_escape_string($_POST['title']);
    $message = $conn->real_escape_string($_POST['message']);
    $type = $conn->real_escape_string($_POST['type']);
    $target_audience = $conn->real_escape_string($_POST['target_audience']);
    $village = $conn->real_escape_string($_POST['village']);
    $posted_by = $conn->real_escape_string($_POST['posted_by']);
    
    $sql = "INSERT INTO communications (title, message, type, target_audience, village, posted_by) 
            VALUES ('$title', '$message', '$type', '$target_audience', '$village', '$posted_by')";
    
    if ($conn->query($sql)) {
        $_SESSION['message'] = "Announcement posted successfully";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $conn->error;
        $_SESSION['message_type'] = "danger";
    }
    header("Location: communications.php");
    exit();
}

$communications = $conn->query("SELECT * FROM communications ORDER BY sent_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - <?php echo SITE_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f0f2f5; }
        .navbar { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); padding: 15px; }
        .navbar-brand, .nav-link { color: white !important; }
        .btn-custom { background: linear-gradient(135deg, #1a5f7a 0%, #159895 100%); border: none; color: white; }
        .announcement-card { border-left: 4px solid #1a5f7a; margin-bottom: 15px; }
        .emergency-card { border-left: 4px solid #dc3545; background: #fff5f5; }
        footer { background: #2c3e50; color: white; padding: 20px 0; margin-top: 50px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><i class="fas fa-village"></i> <?php echo SITE_NAME; ?></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="residents.php">Residents</a></li>
                <li class="nav-item"><a class="nav-link" href="projects.php">Projects</a></li>
                <li class="nav-item"><a class="nav-link active" href="communications.php">Announcements</a></li>
                <li class="nav-item"><a class="nav-link" href="feedback.php">Feedback</a></li>
                <li class="nav-item"><a class="nav-link" href="contactus.php">Contact Page</a></li>
                <li class="nav-item"><a class="nav-link" href="reports.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-bullhorn me-2"></i>Announcements & Communications</h2>
        <button class="btn btn-custom" data-bs-toggle="modal" data-bs-target="#addAnnouncementModal">
            <i class="fas fa-plus"></i> New Announcement
        </button>
    </div>
    
    <?php display_message(); ?>
    
    <div class="row">
        <div class="col-md-8">
            <?php while($comm = $communications->fetch_assoc()): ?>
            <div class="card <?php echo $comm['type'] == 'Emergency' ? 'emergency-card' : 'announcement-card'; ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6><i class="fas fa-<?php echo $comm['type'] == 'Emergency' ? 'exclamation-triangle text-danger' : 'bullhorn'; ?>"></i> <?php echo $comm['title']; ?></h6>
                        <small class="text-muted"><?php echo date('M j, Y H:i', strtotime($comm['sent_date'])); ?></small>
                    </div>
                    <p class="card-text mt-2"><?php echo nl2br($comm['message']); ?></p>
                    <small class="text-muted">Posted by: <?php echo $comm['posted_by']; ?> | Target: <?php echo $comm['target_audience']; ?></small>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header bg-white">
                    <h6><i class="fas fa-info-circle"></i> Quick Information</h6>
                </div>
                <div class="card-body">
                    <p><strong>Emergency Contacts:</strong></p>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-phone"></i> Chief's Office: <strong>0700 000 000</strong></li>
                        <li><i class="fas fa-ambulance"></i> Health Center: <strong>0700 111 111</strong></li>
                        <li><i class="fas fa-shield-alt"></i> Police Post: <strong>0700 222 222</strong></li>
                    </ul>
                    <hr>
                    <p><strong>Next Baraza:</strong><br>Every 1st and 15th of the month at 10:00 AM at the village center.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Announcement Modal -->
<div class="modal fade" id="addAnnouncementModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Post New Announcement</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3"><label>Title *</label><input type="text" name="title" class="form-control" required></div>
                    <div class="mb-3"><label>Type *</label><select name="type" class="form-control" required><option>Announcement</option><option>Emergency</option><option>Meeting</option><option>Project Update</option></select></div>
                    <div class="mb-3"><label>Target Audience *</label><select name="target_audience" class="form-control" required><option>All</option><option>Village Elders</option><option>Residents</option></select></div>
                    <div class="mb-3"><label>Village (Optional)</label><input type="text" name="village" class="form-control" placeholder="Leave blank for all"></div>
                    <div class="mb-3"><label>Posted By</label><input type="text" name="posted_by" class="form-control" value="Village Administrator"></div>
                    <div class="mb-3"><label>Message *</label><textarea name="message" class="form-control" rows="5" required></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-custom">Post Announcement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<footer>
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Narok County, Kenya</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>